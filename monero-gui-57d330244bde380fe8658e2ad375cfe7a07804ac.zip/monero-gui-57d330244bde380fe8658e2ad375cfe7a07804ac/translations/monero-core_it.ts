<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="it">
<context>
    <name>Account</name>
    <message>
        <location filename="../pages/Account.qml" line="55"/>
        <source>Set the label of the selected account:</source>
        <translation>Imposta l&apos;etichetta dell&apos;account selezionato:</translation>
    </message>
    <message>
        <location filename="../pages/Account.qml" line="87"/>
        <source>Balance All</source>
        <translation>Saldo totale</translation>
    </message>
    <message>
        <location filename="../pages/Account.qml" line="94"/>
        <source>Total balance: </source>
        <translation>Saldo Totale: </translation>
    </message>
    <message>
        <location filename="../pages/Account.qml" line="117"/>
        <location filename="../pages/Account.qml" line="150"/>
        <source>Copied to clipboard</source>
        <translation>Copiato negli appunti</translation>
    </message>
    <message>
        <location filename="../pages/Account.qml" line="127"/>
        <source>Total unlocked balance: </source>
        <translation>Totale saldo sbloccato: </translation>
    </message>
    <message>
        <location filename="../pages/Account.qml" line="165"/>
        <source>Accounts</source>
        <translation>Accounts</translation>
    </message>
    <message>
        <location filename="../pages/Account.qml" line="258"/>
        <source>Balance: </source>
        <translation>Saldo: </translation>
    </message>
    <message>
        <location filename="../pages/Account.qml" line="319"/>
        <source>Address copied to clipboard</source>
        <translation>Indirizzo copiato negli appunti</translation>
    </message>
    <message>
        <location filename="../pages/Account.qml" line="354"/>
        <source>Create new account</source>
        <translation>Crea nuovo account</translation>
    </message>
    <message>
        <location filename="../pages/Account.qml" line="356"/>
        <source>Set the label of the new account:</source>
        <translation>Imposta l&apos;etichetta del nuovo account:</translation>
    </message>
</context>
<context>
    <name>AddressBook</name>
    <message>
        <location filename="../pages/AddressBook.qml" line="80"/>
        <source>Save your most used addresses here</source>
        <translation>Salva qui gli indirizzi più utilizzati</translation>
    </message>
    <message>
        <location filename="../pages/AddressBook.qml" line="100"/>
        <source>This makes it easier to send or receive Monero and reduces errors when typing in addresses manually.</source>
        <translation>Questo semplifica l&apos;invio o la ricezione di Monero riducendo gli errori durante la digitazione manuale degli indirizzi.</translation>
    </message>
    <message>
        <location filename="../pages/AddressBook.qml" line="114"/>
        <location filename="../pages/AddressBook.qml" line="303"/>
        <source>Add an address</source>
        <translation>Aggiungi un indirizzo</translation>
    </message>
    <message>
        <location filename="../pages/AddressBook.qml" line="129"/>
        <source>Address book</source>
        <translation>Rubrica</translation>
    </message>
    <message>
        <location filename="../pages/AddressBook.qml" line="257"/>
        <source>Address copied to clipboard</source>
        <translation>Indirizzo copiato negli appunti</translation>
    </message>
    <message>
        <location filename="../pages/AddressBook.qml" line="288"/>
        <source>Add address</source>
        <translation>Aggiungi indirizzo</translation>
    </message>
    <message>
        <location filename="../pages/AddressBook.qml" line="303"/>
        <source>Edit an address</source>
        <translation>Modifica un indirizzo</translation>
    </message>
    <message>
        <location filename="../pages/AddressBook.qml" line="309"/>
        <source>&lt;style type=&apos;text/css&apos;&gt;a {text-decoration: none; color: #858585; font-size: 14px;}&lt;/style&gt;                                 Address</source>
        <translation>&lt;style type=&apos;text/css&apos;&gt;a {text-decoration: none; color: #858585; font-size: 14px;}&lt;/style&gt;                                 Indirizzo</translation>
    </message>
    <message>
        <location filename="../pages/AddressBook.qml" line="348"/>
        <source>Resolve</source>
        <translation>Risolvi</translation>
    </message>
    <message>
        <location filename="../pages/AddressBook.qml" line="363"/>
        <source>No valid address found at this OpenAlias address</source>
        <translation>Nessun indirizzo valido trovato per questo indirizzo OpenAlias</translation>
    </message>
    <message>
        <location filename="../pages/AddressBook.qml" line="368"/>
        <source>Address found, but the DNSSEC signatures could not be verified, so this address may be spoofed</source>
        <translation>Indirizzo trovato ma le firme DNSSEC non sono potute essere verificate. L&apos;indirizzo potrebbe essere alterato</translation>
    </message>
    <message>
        <location filename="../pages/AddressBook.qml" line="370"/>
        <source>No valid address found at this OpenAlias address, but the DNSSEC signatures could not be verified, so this may be spoofed</source>
        <translation>Nessun indirizzo valido trovato in questo indirizzo OpenAlias ma le firme DNSSEC non sono potute essere verificate, l&apos;indirizzo potrebbe essere alterato</translation>
    </message>
    <message>
        <location filename="../pages/AddressBook.qml" line="373"/>
        <location filename="../pages/AddressBook.qml" line="376"/>
        <source>Internal error</source>
        <translation>Errore interno</translation>
    </message>
    <message>
        <location filename="../pages/AddressBook.qml" line="379"/>
        <source>No address found</source>
        <translation>Nessun indirizzo trovato</translation>
    </message>
    <message>
        <location filename="../pages/AddressBook.qml" line="387"/>
        <source>&lt;style type=&apos;text/css&apos;&gt;a {text-decoration: none; color: #858585; font-size: 14px;}&lt;/style&gt;                                 Description</source>
        <translation>&lt;style type=&apos;text/css&apos;&gt;a {text-decoration: none; color: #858585; font-size: 14px;}&lt;/style&gt;                                 Descrizione</translation>
    </message>
    <message>
        <location filename="../pages/AddressBook.qml" line="389"/>
        <source>Add a name...</source>
        <translation>Aggiungi un nome...</translation>
    </message>
    <message>
        <location filename="../pages/AddressBook.qml" line="395"/>
        <source>Add</source>
        <translation>Aggiungi</translation>
    </message>
    <message>
        <location filename="../pages/AddressBook.qml" line="395"/>
        <source>Save</source>
        <translation>Salva</translation>
    </message>
    <message>
        <location filename="../pages/AddressBook.qml" line="400"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../pages/AddressBook.qml" line="403"/>
        <source>Invalid address</source>
        <translation>Indirizzo invalido</translation>
    </message>
    <message>
        <location filename="../pages/AddressBook.qml" line="407"/>
        <source>Can&apos;t create entry</source>
        <translation>Impossibile creare questa voce</translation>
    </message>
    <message>
        <location filename="../pages/AddressBook.qml" line="426"/>
        <source>Cancel</source>
        <translation>Cancella</translation>
    </message>
    <message>
        <location filename="../pages/AddressBook.qml" line="443"/>
        <source>Delete</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <location filename="../pages/AddressBook.qml" line="503"/>
        <source>OpenAlias error</source>
        <translation>Errore OpenAlias</translation>
    </message>
</context>
<context>
    <name>ContextMenu</name>
    <message>
        <location filename="../components/ContextMenu.qml" line="37"/>
        <source>Paste</source>
        <translation type="unfinished">Incollare</translation>
    </message>
</context>
<context>
    <name>DaemonManagerDialog</name>
    <message>
        <location filename="../components/DaemonManagerDialog.qml" line="93"/>
        <source>Starting local node in %1 seconds</source>
        <translation>Nodo locale in avvio tra %1 secondi</translation>
    </message>
    <message>
        <location filename="../components/DaemonManagerDialog.qml" line="113"/>
        <source>Start daemon (%1)</source>
        <translation>Avvio daemon (%1)</translation>
    </message>
    <message>
        <location filename="../components/DaemonManagerDialog.qml" line="126"/>
        <source>Use custom settings</source>
        <translation>Utilizza impostazioni personalizzate</translation>
    </message>
</context>
<context>
    <name>History</name>
    <message>
        <location filename="../pages/History.qml" line="189"/>
        <source>Date from</source>
        <translation>Data da</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="203"/>
        <source>Date to</source>
        <translation>Data a</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="310"/>
        <location filename="../pages/History.qml" line="855"/>
        <location filename="../pages/History.qml" line="1636"/>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="89"/>
        <source>Transactions</source>
        <translation>Transazioni</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="109"/>
        <source>Sort &amp; filter</source>
        <translation>Ordina e filtra</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="159"/>
        <source>Search...</source>
        <translation>Ricerca...</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="230"/>
        <source>Sort by</source>
        <translation>Ordina per</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="251"/>
        <location filename="../pages/History.qml" line="747"/>
        <source>Blockheight</source>
        <translation>Altezza di blocco</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="369"/>
        <location filename="../pages/History.qml" line="1637"/>
        <source>Amount</source>
        <translation>Importo</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="449"/>
        <source>Page</source>
        <translation>Pagina</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="479"/>
        <source>Jump to page (1-%1)</source>
        <translation>Vai alla pagina (1-%1)</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="487"/>
        <source>Invalid page. Must be a number within the specified range.</source>
        <translation>Pagina non valida. Deve essere un numero compreso nell&apos;intervallo specificato.</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="636"/>
        <source>Sent</source>
        <translation>Inviato</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="636"/>
        <source>Received</source>
        <translation>Ricevuto</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="686"/>
        <source>Fee</source>
        <translation>Commissione</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="686"/>
        <source>Mined</source>
        <translation>Minato</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="703"/>
        <source>Yes</source>
        <translation>Si</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="763"/>
        <source>Pending</source>
        <translation>In attesa</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="798"/>
        <source>Confirmations</source>
        <translation>Conferme</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="971"/>
        <source>Description</source>
        <translation>Descrizione</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1039"/>
        <source>Transaction ID</source>
        <translation>ID transazione</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1083"/>
        <source>Transaction key</source>
        <translation>Chiave di transazione</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1099"/>
        <source>Click to reveal</source>
        <translation>Clicca per mostrare</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1129"/>
        <source>Address sent to</source>
        <translation>Indirizzo inviato a</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1152"/>
        <source>Waiting for transaction to leave txpool.</source>
        <translation>In attesa che la transazione lasci il txpool.</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1154"/>
        <source>Unknown recipient</source>
        <translation>Destinatario sconosciuto</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1297"/>
        <source>Advanced options</source>
        <translation>Opzioni avanzate</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1313"/>
        <source>Human readable date format</source>
        <translation>Data in formato leggibile</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1319"/>
        <source>Export all history</source>
        <translation>Esporta tutta la cronologia</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1536"/>
        <source>Set description:</source>
        <translation>Imposta descrizione:</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1539"/>
        <source>Updated description.</source>
        <translation>Descrizione aggiornata.</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1569"/>
        <source>No transaction history yet.</source>
        <translation>Ancora nessuna cronologia delle transazioni.</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1571"/>
        <source>No results.</source>
        <translation>Nessun risultato.</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1573"/>
        <source>%1 transactions total, showing %2.</source>
        <translation>%1 transazioni totali, mostrando %2.</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1591"/>
        <source>Primary address</source>
        <translation>Indirizzo primario</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1600"/>
        <source>Transaction details</source>
        <translation>Dettagli della transazione</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1626"/>
        <source>Copied to clipboard</source>
        <translation>Copiato negli appunti</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1635"/>
        <source>Tx ID:</source>
        <translation>ID Tx:</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1638"/>
        <source>Address:</source>
        <translation>Indirizzo:</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1639"/>
        <source>Payment ID:</source>
        <translation>ID pagamento:</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1640"/>
        <source>Integrated address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1641"/>
        <source>Tx key:</source>
        <translation>Chiave Tx:</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1642"/>
        <source>Tx note:</source>
        <translation>Nota Tx:</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1643"/>
        <source>Destinations:</source>
        <translation>Destinazioni:</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1644"/>
        <source>Rings:</source>
        <translation>Anelli:</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1661"/>
        <source>Please choose a folder</source>
        <translation>Per favore scegli una cartella</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1671"/>
        <source>Success</source>
        <translation>Successo</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1672"/>
        <source>CSV file written to: %1</source>
        <translation>FIle CSV scritto su: %1</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1673"/>
        <source>Tip: Use your favorite spreadsheet software to sort on blockheight.</source>
        <translation>Suggerimento: utilizza il tuo software preferito per fogli di calcolo elettronici per ordinare in base all&apos;altezza del blocco.</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1677"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../pages/History.qml" line="1678"/>
        <source>Error exporting transaction data.</source>
        <translation>Errore nell&apos;esportazione dei dati della transazione.</translation>
    </message>
</context>
<context>
    <name>InputDialog</name>
    <message>
        <location filename="../components/InputDialog.qml" line="135"/>
        <source>Cancel</source>
        <translation>Cancella</translation>
    </message>
    <message>
        <location filename="../components/InputDialog.qml" line="147"/>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
</context>
<context>
    <name>Keys</name>
    <message>
        <location filename="../pages/Keys.qml" line="73"/>
        <source>Mnemonic seed</source>
        <translation>Seed mnemonico</translation>
    </message>
    <message>
        <location filename="../pages/Keys.qml" line="134"/>
        <source>Keys</source>
        <translation>Chiavi</translation>
    </message>
    <message>
        <location filename="../pages/Keys.qml" line="62"/>
        <source>WARNING: Do not reuse your Monero keys on another fork, UNLESS this fork has key reuse mitigations built in. Doing so will harm your privacy.</source>
        <translation>ATTENZIONE: Non riusare le tue chiavi Monero su un altro fork, A MENO CHE questo fork abbia incorporate delle tecniche di mitigazione per il riuso delle chiavi. Facendo questo potrebbe ledere la tua privacy.</translation>
    </message>
    <message>
        <location filename="../pages/Keys.qml" line="85"/>
        <source>WARNING: Copying your seed to clipboard can expose you to malicious software, which may record your seed and steal your Monero. Please write down your seed manually.</source>
        <translation>ATTENZIONE: Copiando il seed negli appunti potresti esporlo a malware, che potrebbe copiare il tuo seed e rubare i tuoi Monero. Raccomandiamo di scrivere il seed manualmente.</translation>
    </message>
    <message>
        <location filename="../pages/Keys.qml" line="106"/>
        <source>Wallet restore height</source>
        <translation>Altezza di ripristino portafoglio</translation>
    </message>
    <message>
        <location filename="../pages/Keys.qml" line="122"/>
        <source>Block #</source>
        <translation>blocco #</translation>
    </message>
    <message>
        <location filename="../pages/Keys.qml" line="187"/>
        <source>Export wallet</source>
        <translation>Esporta portafoglio</translation>
    </message>
    <message>
        <location filename="../pages/Keys.qml" line="202"/>
        <location filename="../pages/Keys.qml" line="244"/>
        <source>Spendable Wallet</source>
        <translation>Portafoglio spendibile</translation>
    </message>
    <message>
        <location filename="../pages/Keys.qml" line="212"/>
        <location filename="../pages/Keys.qml" line="244"/>
        <source>View Only Wallet</source>
        <translation>Portafoglio solo-visualizzazione</translation>
    </message>
    <message>
        <location filename="../pages/Keys.qml" line="250"/>
        <source>Done</source>
        <translation>Eseguito</translation>
    </message>
    <message>
        <location filename="../pages/Keys.qml" line="270"/>
        <source>Mnemonic seed protected by hardware device.</source>
        <translation>Seed mnemonico protetto da dispositivo hardware.</translation>
    </message>
    <message>
        <location filename="../pages/Keys.qml" line="280"/>
        <source>(View Only Wallet - No mnemonic seed available)</source>
        <translation>(Portafoglio solo-visualizzazione - Nessun seed mnemonico disponibile)</translation>
    </message>
    <message>
        <location filename="../pages/Keys.qml" line="281"/>
        <source>(View Only Wallet - No secret spend key available)</source>
        <translation>(Portafoglio solo-lettura - Nessuna chiave di spesa segreta disponibile)</translation>
    </message>
    <message>
        <location filename="../pages/Keys.qml" line="288"/>
        <source>(Hardware Device Wallet - No secret spend key available)</source>
        <translation>(Portafoglio dispositivo hardware - Nessuna chiave di spesa segreta disponibile)</translation>
    </message>
    <message>
        <location filename="../pages/Keys.qml" line="148"/>
        <source>Secret view key</source>
        <translation>Chiave segreta di visualizzazione</translation>
    </message>
    <message>
        <location filename="../pages/Keys.qml" line="157"/>
        <source>Public view key</source>
        <translation>Chiave pubblica di visualizzazione</translation>
    </message>
    <message>
        <location filename="../pages/Keys.qml" line="166"/>
        <source>Secret spend key</source>
        <translation>Chiave segreta di spesa</translation>
    </message>
    <message>
        <location filename="../pages/Keys.qml" line="175"/>
        <source>Public spend key</source>
        <translation>Chiave pubblica di spesa</translation>
    </message>
</context>
<context>
    <name>LeftPanel</name>
    <message>
        <location filename="../LeftPanel.qml" line="397"/>
        <source>Send</source>
        <translation>Invia</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="441"/>
        <source>Receive</source>
        <translation>Ricevi</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="442"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="553"/>
        <source>Prove/check</source>
        <translation>Prova/controlla</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="554"/>
        <source>K</source>
        <translation>K</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="164"/>
        <source>View Only</source>
        <translation>Solo Visualizzazione</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="150"/>
        <source>Testnet</source>
        <translation>Testnet</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="150"/>
        <source>Stagenet</source>
        <translation>Stagenet</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="300"/>
        <source>Copied to clipboard</source>
        <translation>Copiato negli appunti</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="187"/>
        <location filename="../LeftPanel.qml" line="376"/>
        <source>Account</source>
        <translation>Account</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="226"/>
        <source>Syncing...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="377"/>
        <source>T</source>
        <translation>T</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="419"/>
        <source>Address book</source>
        <translation>Rubrica</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="420"/>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="464"/>
        <source>Merchant</source>
        <translation>Commerciante</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="465"/>
        <source>U</source>
        <translation>U</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="487"/>
        <source>Transactions</source>
        <translation>Transazioni</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="488"/>
        <source>H</source>
        <translation>H</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="509"/>
        <source>Advanced</source>
        <translation>Avanzate</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="510"/>
        <source>D</source>
        <translation>D</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="530"/>
        <source>Mining</source>
        <translation>Mining</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="531"/>
        <source>M</source>
        <translation>M</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="576"/>
        <source>Shared RingDB</source>
        <translation>RingDB condiviso</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="669"/>
        <source>Wallet</source>
        <translation>Portafoglio</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="678"/>
        <source>Daemon</source>
        <translation>Daemon</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="599"/>
        <source>Sign/verify</source>
        <translation>Firma/verifica</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="577"/>
        <source>G</source>
        <translation>G</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="600"/>
        <source>I</source>
        <translation>I</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="621"/>
        <source>Settings</source>
        <translation>Impostazioni</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="622"/>
        <source>E</source>
        <translation>E</translation>
    </message>
    <message>
        <location filename="../LeftPanel.qml" line="398"/>
        <source>S</source>
        <translation>S</translation>
    </message>
</context>
<context>
    <name>LineEdit</name>
    <message>
        <location filename="../components/LineEdit.qml" line="132"/>
        <source>Copy</source>
        <translation>Copia</translation>
    </message>
    <message>
        <location filename="../components/LineEdit.qml" line="138"/>
        <source>Copied to clipboard</source>
        <translation>Copiato negli appunti</translation>
    </message>
</context>
<context>
    <name>LineEditMulti</name>
    <message>
        <location filename="../components/LineEditMulti.qml" line="134"/>
        <source>Copy</source>
        <translation>Copia</translation>
    </message>
    <message>
        <location filename="../components/LineEditMulti.qml" line="139"/>
        <source>Copied to clipboard</source>
        <translation>Copiato negli appunti</translation>
    </message>
    <message>
        <location filename="../components/LineEditMulti.qml" line="150"/>
        <source>Paste</source>
        <translation>Incollare</translation>
    </message>
</context>
<context>
    <name>Merchant</name>
    <message>
        <location filename="../pages/merchant/Merchant.qml" line="128"/>
        <source>Sales</source>
        <translation>Vendite</translation>
    </message>
    <message>
        <location filename="../pages/merchant/Merchant.qml" line="154"/>
        <source>&lt;style&gt;p{font-size:14px;}&lt;/style&gt;&lt;p&gt;This page will automatically scan the blockchain and the tx pool for incoming transactions using the QR code.&lt;/p&gt;&lt;p&gt;It&apos;s up to you whether to accept unconfirmed transactions or not. It is likely they&apos;ll be confirmed in short order, but there is still a possibility they might not, so for larger values you may want to wait for one or more confirmation(s).&lt;/p&gt;</source>
        <translation>&lt;style&gt;p{font-size:14px;}&lt;/style&gt;&lt;p&gt;Questa pagina scansionerà automaticamente la blockchain e il pool tx per le transazioni in entrata usando il codice QR.&lt;/p&gt;&lt;p&gt; Sta a te decidere se accettare transazioni non confermate o meno. È probabile che vengano confermate in breve tempo, ma c&apos;è anche la possibilità che non lo siano, quindi per somme di valore più elevato sarebbe meglio aspettare una o più conferme prima di accettare la transazione come valida.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../pages/merchant/Merchant.qml" line="165"/>
        <location filename="../pages/merchant/Merchant.qml" line="646"/>
        <source>Currently monitoring incoming transactions, none found yet.</source>
        <translation>Monitorando attualmente le transazioni in entrata, ancora nessuna trovata.</translation>
    </message>
    <message>
        <location filename="../pages/merchant/Merchant.qml" line="235"/>
        <source>Save As</source>
        <translation>Salva come</translation>
    </message>
    <message>
        <location filename="../pages/merchant/Merchant.qml" line="268"/>
        <source>&lt;style type=&apos;text/css&apos;&gt;a {text-decoration: none; color: #FF6C3C; font-size: 12px;}&lt;/style&gt;Currently selected address: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/merchant/Merchant.qml" line="268"/>
        <source> &lt;a href=&apos;#&apos;&gt;(Change)&lt;/a&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/merchant/Merchant.qml" line="293"/>
        <source>(right-click, save as)</source>
        <translation>(clic con il pulsante destro, Salva come)</translation>
    </message>
    <message>
        <location filename="../pages/merchant/Merchant.qml" line="337"/>
        <source>Payment URL</source>
        <translation>URL del pagamento</translation>
    </message>
    <message>
        <location filename="../pages/merchant/Merchant.qml" line="416"/>
        <source>Copied to clipboard</source>
        <translation>Copiato negli appunti</translation>
    </message>
    <message>
        <location filename="../pages/merchant/Merchant.qml" line="449"/>
        <location filename="../pages/merchant/Merchant.qml" line="502"/>
        <source>Amount to receive</source>
        <translation>Importo da ricevere</translation>
    </message>
    <message>
        <location filename="../pages/merchant/Merchant.qml" line="529"/>
        <source>Enable sales tracker</source>
        <translation>Abilita programma per gestione vendite</translation>
    </message>
    <message>
        <location filename="../pages/merchant/Merchant.qml" line="541"/>
        <source>Leave this page</source>
        <translation>Esci da questa pagina</translation>
    </message>
    <message>
        <location filename="../pages/merchant/Merchant.qml" line="571"/>
        <source>The merchant page requires a larger window</source>
        <translation>La pagina del commerciante necessita una finestra più grande</translation>
    </message>
    <message>
        <location filename="../pages/merchant/Merchant.qml" line="586"/>
        <source>WARNING: no connection to daemon</source>
        <translation>AVVISO: non connesso al daemon</translation>
    </message>
    <message>
        <location filename="../pages/merchant/Merchant.qml" line="690"/>
        <source>Save QrCode</source>
        <translation>Salva codice QR</translation>
    </message>
    <message>
        <location filename="../pages/merchant/Merchant.qml" line="691"/>
        <source>Failed to save QrCode to </source>
        <translation>Impossibile salvare codice QR in </translation>
    </message>
</context>
<context>
    <name>MerchantTrackingList</name>
    <message>
        <location filename="../pages/merchant/MerchantTrackingList.qml" line="103"/>
        <source>show</source>
        <translation>mostra</translation>
    </message>
    <message>
        <location filename="../pages/merchant/MerchantTrackingList.qml" line="103"/>
        <source>hide</source>
        <translation>nascondi</translation>
    </message>
    <message>
        <location filename="../pages/merchant/MerchantTrackingList.qml" line="163"/>
        <source>Awaiting in txpool</source>
        <translation>In attesa nel pool transazioni</translation>
    </message>
    <message>
        <location filename="../pages/merchant/MerchantTrackingList.qml" line="167"/>
        <location filename="../pages/merchant/MerchantTrackingList.qml" line="169"/>
        <source>confirmations</source>
        <translation>conferme</translation>
    </message>
    <message>
        <location filename="../pages/merchant/MerchantTrackingList.qml" line="172"/>
        <source>confirmation</source>
        <translation>conferma</translation>
    </message>
</context>
<context>
    <name>Mining</name>
    <message>
        <location filename="../pages/Mining.qml" line="54"/>
        <source>Solo mining</source>
        <translation>Solo mining</translation>
    </message>
    <message>
        <location filename="../pages/Mining.qml" line="65"/>
        <source>Your daemon must be synchronized before you can start mining</source>
        <translation>Il daemon deve essere sincronizzato prima di iniziare il mining</translation>
    </message>
    <message>
        <location filename="../pages/Mining.qml" line="99"/>
        <source>CPU threads</source>
        <translation>Threads CPU</translation>
    </message>
    <message>
        <location filename="../pages/Mining.qml" line="59"/>
        <source>Mining is only available on local daemons.</source>
        <translation>È possibile minare solo con il daemon locale.</translation>
    </message>
    <message>
        <location filename="../pages/Mining.qml" line="71"/>
        <source>Mining with your computer helps strengthen the Monero network. The more that people mine, the harder it is for the network to be attacked, and every little bit helps.

Mining also gives you a small chance to earn some Monero. Your computer will create hashes looking for block solutions. If you find a block, you will get the associated reward. Good luck!</source>
        <translation>Minare con il tuo computer contribuisce a rafforzare la rete Monero. Più gente mina, più difficile sarà attaccare la rete, ed ognuno minando può dare il suo contributo.

Minare ti offre anche una piccola possibilità di guadagnare un po&apos; di Monero. Il tuo computer creerà hashes nel tentativo di risolvere un blocco. Se trovi un blocco, otterrai la ricompensa associata. In bocca al lupo!</translation>
    </message>
    <message>
        <location filename="../pages/Mining.qml" line="83"/>
        <source>Mining may reduce the performance of other running applications and processes.</source>
        <translation>L&apos;attività di mining può ridurre le prestazioni di altre applicazioni e processi in esecuzione.</translation>
    </message>
    <message>
        <location filename="../pages/Mining.qml" line="118"/>
        <source>Max # of CPU threads available for mining: </source>
        <translation>Numero massimo di thread della CPU disponibili per il mining: </translation>
    </message>
    <message>
        <location filename="../pages/Mining.qml" line="129"/>
        <source>Use recommended # of threads</source>
        <translation>Utilizzare il numero di thread consigliato</translation>
    </message>
    <message>
        <location filename="../pages/Mining.qml" line="133"/>
        <source>Set to use recommended # of threads</source>
        <translation>Imposta il numero consigliato di thread</translation>
    </message>
    <message>
        <location filename="../pages/Mining.qml" line="140"/>
        <source>Use all threads</source>
        <translation>Utilizza tutti i thread</translation>
    </message>
    <message>
        <location filename="../pages/Mining.qml" line="144"/>
        <source>Set to use all threads</source>
        <translation>Imposta per utilizzare tutti i thread disponibili</translation>
    </message>
    <message>
        <location filename="../pages/Mining.qml" line="155"/>
        <source>Background mining (experimental)</source>
        <translation>Minare in background (sperimentale)</translation>
    </message>
    <message>
        <location filename="../pages/Mining.qml" line="167"/>
        <source>Enable mining when running on battery</source>
        <translation>Abilitare mining quando in alimentazione da batteria</translation>
    </message>
    <message>
        <location filename="../pages/Mining.qml" line="178"/>
        <source>Manage miner</source>
        <translation>Gestisci miner</translation>
    </message>
    <message>
        <location filename="../pages/Mining.qml" line="194"/>
        <source>Start mining</source>
        <translation>Avvia mining</translation>
    </message>
    <message>
        <location filename="../pages/Mining.qml" line="200"/>
        <source>Error starting mining</source>
        <translation>Errore durante avvio mining</translation>
    </message>
    <message>
        <location filename="../pages/Mining.qml" line="201"/>
        <source>Couldn&apos;t start mining.&lt;br&gt;</source>
        <translation>Impossibile avviare mining&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../pages/Mining.qml" line="203"/>
        <source>Mining is only available on local daemons. Run a local daemon to be able to mine.&lt;br&gt;</source>
        <translation>Il mining è possibile solo utilizzando il daemon locale. Avvia daemon locale per avviare il mining&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../pages/Mining.qml" line="214"/>
        <source>Stop mining</source>
        <translation>Arresta mining</translation>
    </message>
    <message>
        <location filename="../pages/Mining.qml" line="230"/>
        <source>Status</source>
        <translation>Stato</translation>
    </message>
    <message>
        <location filename="../pages/Mining.qml" line="254"/>
        <source>Mining at %1 H/s</source>
        <translation>Mining attivo a %1 H/s</translation>
    </message>
    <message>
        <location filename="../pages/Mining.qml" line="242"/>
        <location filename="../pages/Mining.qml" line="257"/>
        <source>Not mining</source>
        <translation>Mining non avviato</translation>
    </message>
</context>
<context>
    <name>Navbar</name>
    <message>
        <location filename="../pages/settings/Navbar.qml" line="141"/>
        <source>Wallet</source>
        <translation>Portafoglio</translation>
    </message>
    <message>
        <location filename="../pages/settings/Navbar.qml" line="193"/>
        <source>Interface</source>
        <translation>Interfaccia</translation>
    </message>
    <message>
        <location filename="../pages/settings/Navbar.qml" line="246"/>
        <source>Node</source>
        <translation>Nodo</translation>
    </message>
    <message>
        <location filename="../pages/settings/Navbar.qml" line="300"/>
        <source>Log</source>
        <translation>Log</translation>
    </message>
    <message>
        <location filename="../pages/settings/Navbar.qml" line="353"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
</context>
<context>
    <name>NetworkStatusItem</name>
    <message>
        <location filename="../components/NetworkStatusItem.qml" line="120"/>
        <source>Network status</source>
        <translation>Stato Rete</translation>
    </message>
    <message>
        <location filename="../components/NetworkStatusItem.qml" line="47"/>
        <source>Connected</source>
        <translation>Connesso</translation>
    </message>
    <message>
        <location filename="../components/NetworkStatusItem.qml" line="44"/>
        <source>Synchronizing</source>
        <translation>In sincronizzazione</translation>
    </message>
    <message>
        <location filename="../components/NetworkStatusItem.qml" line="46"/>
        <source>Remote node</source>
        <translation>Nodo remoto</translation>
    </message>
    <message>
        <location filename="../components/NetworkStatusItem.qml" line="47"/>
        <source>Mining</source>
        <translation>Mining</translation>
    </message>
    <message>
        <location filename="../components/NetworkStatusItem.qml" line="50"/>
        <source>Wrong version</source>
        <translation>Versione errata</translation>
    </message>
    <message>
        <location filename="../components/NetworkStatusItem.qml" line="53"/>
        <source>Searching node</source>
        <translation>Ricerca del nodo</translation>
    </message>
    <message>
        <location filename="../components/NetworkStatusItem.qml" line="55"/>
        <source>Disconnected</source>
        <translation>Disconnesso</translation>
    </message>
    <message>
        <location filename="../components/NetworkStatusItem.qml" line="58"/>
        <source>Invalid connection status</source>
        <translation>Stato della connessione non valido</translation>
    </message>
    <message>
        <location filename="../components/NetworkStatusItem.qml" line="177"/>
        <source>Successfully switched to another public node</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../components/NetworkStatusItem.qml" line="180"/>
        <source>Failed to switch public node</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../components/NetworkStatusItem.qml" line="190"/>
        <source>Switching to another public node</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PasswordDialog</name>
    <message>
        <location filename="../components/PasswordDialog.qml" line="140"/>
        <source>Please enter new wallet password</source>
        <translation>Inserisci una nuova password per il portafoglio</translation>
    </message>
    <message>
        <location filename="../components/PasswordDialog.qml" line="142"/>
        <source>wallet password</source>
        <translation>password per il portafoglio</translation>
    </message>
    <message>
        <location filename="../components/PasswordDialog.qml" line="142"/>
        <source>wallet device passphrase</source>
        <translation>passphrase per il dispositivo del portafoglio</translation>
    </message>
    <message>
        <location filename="../components/PasswordDialog.qml" line="143"/>
        <source>Please enter %1 for: </source>
        <translation>Prego inserire %1 per: </translation>
    </message>
    <message>
        <location filename="../components/PasswordDialog.qml" line="143"/>
        <source>Please enter %1</source>
        <translation>Prego inserire %1</translation>
    </message>
    <message>
        <location filename="../components/PasswordDialog.qml" line="155"/>
        <source>Warning: passphrase entry on host is a security risk as it can be captured by malware. It is advised to prefer device-based passphrase entry.</source>
        <translation>Attenzione: l&apos;immissione della passphrase sull&apos;host costituisce un rischio di sicurezza dal momento che può venire catturata da un malware. Si consiglia di preferire l&apos;immissione della passphrase basata su dispositivo.</translation>
    </message>
    <message>
        <location filename="../components/PasswordDialog.qml" line="184"/>
        <source>CAPSLOCKS IS ON.</source>
        <translation>CAPSLOCK È ATTIVO.</translation>
    </message>
    <message>
        <location filename="../components/PasswordDialog.qml" line="289"/>
        <source>Please confirm new password</source>
        <translation>Conferma la nuova password</translation>
    </message>
    <message>
        <location filename="../components/PasswordDialog.qml" line="289"/>
        <source>Please confirm wallet device passphrase</source>
        <translation>Prego confermare passphrase per il dispositivo del portafoglio</translation>
    </message>
    <message>
        <location filename="../components/PasswordDialog.qml" line="395"/>
        <source>Cancel</source>
        <translation>Cancella</translation>
    </message>
    <message>
        <location filename="../components/PasswordDialog.qml" line="412"/>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
</context>
<context>
    <name>ProgressBar</name>
    <message>
        <location filename="../components/ProgressBar.qml" line="38"/>
        <source>%1 blocks remaining: </source>
        <translation>%1 blocchi rimanenti: </translation>
    </message>
    <message>
        <location filename="../components/ProgressBar.qml" line="72"/>
        <source>Synchronizing %1</source>
        <translation>Sincronizzando %1</translation>
    </message>
</context>
<context>
    <name>QRCodeScanner</name>
    <message>
        <location filename="../components/QRCodeScanner.qml" line="129"/>
        <source>QrCode Scanned</source>
        <translation>Codice QR Scansionato</translation>
    </message>
</context>
<context>
    <name>Receive</name>
    <message>
        <location filename="../pages/Receive.qml" line="55"/>
        <source>Set the label of the selected address:</source>
        <translation>Inserisci l&apos;etichetta dell&apos;indirizzo selezionato:</translation>
    </message>
    <message>
        <location filename="../pages/Receive.qml" line="85"/>
        <source>Addresses</source>
        <translation>Indirizzi</translation>
    </message>
    <message>
        <location filename="../pages/Receive.qml" line="296"/>
        <source>Save as image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/Receive.qml" line="305"/>
        <source>Copy to clipboard</source>
        <translation type="unfinished">Copia negli appunti</translation>
    </message>
    <message>
        <location filename="../pages/Receive.qml" line="310"/>
        <source>Copied to clipboard</source>
        <translation>Copiato negli appunti</translation>
    </message>
    <message>
        <location filename="../pages/Receive.qml" line="317"/>
        <source>Show on device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/Receive.qml" line="337"/>
        <source>Please choose a name</source>
        <translation>Scegli un nome</translation>
    </message>
    <message>
        <location filename="../pages/Receive.qml" line="251"/>
        <source>Set the label of the new address:</source>
        <translation>Inserisci l&apos;etichetta del nuovo indirizzo:</translation>
    </message>
    <message>
        <location filename="../pages/Receive.qml" line="211"/>
        <source>Address copied to clipboard</source>
        <translation>Indirizzo copiato negli appunti</translation>
    </message>
    <message>
        <location filename="../pages/Receive.qml" line="249"/>
        <source>Create new address</source>
        <translation>Crea un nuovo indirizzo</translation>
    </message>
    <message>
        <location filename="../pages/Receive.qml" line="344"/>
        <source>Save QrCode</source>
        <translation>Salva codice QR</translation>
    </message>
    <message>
        <location filename="../pages/Receive.qml" line="345"/>
        <source>Failed to save QrCode to </source>
        <translation>Impossibile salvare codice QR in </translation>
    </message>
</context>
<context>
    <name>RemoteNodeEdit</name>
    <message>
        <location filename="../components/RemoteNodeEdit.qml" line="82"/>
        <source>Remote Node Hostname / IP</source>
        <translation>Hostname / IP Nodo Remoto</translation>
    </message>
    <message>
        <location filename="../components/RemoteNodeEdit.qml" line="101"/>
        <source>Port</source>
        <translation>Porta</translation>
    </message>
</context>
<context>
    <name>SettingsInfo</name>
    <message>
        <location filename="../pages/settings/SettingsInfo.qml" line="46"/>
        <location filename="../pages/settings/SettingsInfo.qml" line="48"/>
        <source>Simple mode</source>
        <translation>Modalità semplice</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsInfo.qml" line="50"/>
        <source>Advanced mode</source>
        <translation>Modalità avanzata</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsInfo.qml" line="70"/>
        <source>GUI version: </source>
        <translation>Versione GUI: </translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsInfo.qml" line="100"/>
        <source>Embedded Monero version: </source>
        <translation>Versione Monero incorporata: </translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsInfo.qml" line="130"/>
        <source>Wallet path: </source>
        <translation>Percorso portafoglio: </translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsInfo.qml" line="185"/>
        <source> &lt;a href=&apos;#&apos;&gt; (Click to change)&lt;/a&gt;</source>
        <translation>&lt;a href=&apos;#&apos;&gt; (Clicca per cambiare)&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsInfo.qml" line="187"/>
        <source>Set a new restore height.
You can enter a block height or a date (YYYY-MM-DD):</source>
        <translation>Seleziona una nuova altezza di ripristino.
Puoi inserire un&apos;altezza di blocco o una data (AAAA-MM-GG):</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsInfo.qml" line="230"/>
        <source>Invalid restore height specified. Must be a number or a date formatted YYYY-MM-DD</source>
        <translation>Altezza di ripristino non valida. Deve essere un numero o una data nel formato AAAA-MM-GG</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsInfo.qml" line="206"/>
        <source>Rescan wallet cache</source>
        <translation>Scannerizza di nuovo la cache del portafoglio</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsInfo.qml" line="175"/>
        <source>Wallet restore height: </source>
        <translation>Altezza ripristino portafoglio:</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsInfo.qml" line="207"/>
        <source>Are you sure you want to rebuild the wallet cache?
The following information will be deleted
- Recipient addresses
- Tx keys
- Tx descriptions

The old wallet cache file will be renamed and can be restored later.
</source>
        <translation>Sei sicuro di voler ricostruire la cache del portafoglio?
Le seguenti informazioni verranno cancellate
- Indirizzi di ricezione
- Chiavi Tx
- Descrizioni Tx

La vecchia cache del wallet verrà rinominata e potrà essere ripristinata successivamente.
	    </translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsInfo.qml" line="215"/>
        <source>Cancel</source>
        <translation>Cancella</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsInfo.qml" line="264"/>
        <source>Wallet log path: </source>
        <translation>Percorso log portafoglio: </translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsInfo.qml" line="307"/>
        <source>Wallet mode: </source>
        <translation>Modalità portafoglio:</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsInfo.qml" line="338"/>
        <source>Graphics mode: </source>
        <translation>Modalità grafica: </translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsInfo.qml" line="372"/>
        <source>Tails: </source>
        <translation>Code:</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsInfo.qml" line="380"/>
        <source>persistent</source>
        <translation>persistenza</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsInfo.qml" line="380"/>
        <source>persistence disabled</source>
        <translation>persistenza disabilitata</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsInfo.qml" line="387"/>
        <source>Copy to clipboard</source>
        <translation>Copia negli appunti</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsInfo.qml" line="409"/>
        <source>Copied to clipboard</source>
        <translation>Copiato negli appunti</translation>
    </message>
</context>
<context>
    <name>SettingsLayout</name>
    <message>
        <location filename="../pages/settings/SettingsLayout.qml" line="58"/>
        <source>Custom decorations</source>
        <translation>Decorazioni personalizzate</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsLayout.qml" line="68"/>
        <source>Hide balance</source>
        <translation>Nascondi saldo</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsLayout.qml" line="86"/>
        <source>Lock wallet on inactivity</source>
        <translation>Blocca il wallet in seguito ad inattività</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsLayout.qml" line="74"/>
        <source>Light theme</source>
        <translation>Tema chiaro</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsLayout.qml" line="102"/>
        <source>minutes</source>
        <translation>minuti</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsLayout.qml" line="102"/>
        <source>minute</source>
        <translation>minuto</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsLayout.qml" line="104"/>
        <source>After </source>
        <translation>Dopo </translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsLayout.qml" line="159"/>
        <source>Enable displaying balance in other currencies</source>
        <translation>Abilita la visualizzazione del saldo in altre valute</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsLayout.qml" line="185"/>
        <source>Price source</source>
        <translation>Fonte del prezzo</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsLayout.qml" line="209"/>
        <source>Currency</source>
        <translation>Valuta</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsLayout.qml" line="237"/>
        <source>Enabling price conversion exposes your IP address to the selected price source.</source>
        <translation>Abilitare la conversione del prezzo espone il tuo indirizzo IP alla fonte del prezzo selezionata.</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsLayout.qml" line="244"/>
        <source>Confirm and enable</source>
        <translation>Conferma e abilita</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsLayout.qml" line="259"/>
        <source>Change language</source>
        <translation>Cambia lingua</translation>
    </message>
</context>
<context>
    <name>SettingsLog</name>
    <message>
        <location filename="../pages/settings/SettingsLog.qml" line="68"/>
        <source>Log level</source>
        <translation>Livello log</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsLog.qml" line="134"/>
        <source>Daemon log</source>
        <translation>Log daemon</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsLog.qml" line="217"/>
        <source>command + enter (e.g &apos;help&apos; or &apos;status&apos;)</source>
        <translation>comando + enter (esempio &apos;help&apos; o &apos;status&apos;)</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsLog.qml" line="224"/>
        <source>Failed to send command</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SettingsNode</name>
    <message>
        <location filename="../pages/settings/SettingsNode.qml" line="115"/>
        <source>Local node</source>
        <translation>Nodo locale</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsNode.qml" line="131"/>
        <source>The blockchain is downloaded to your computer. Provides higher security and requires more local storage.</source>
        <translation>La blockchain viene scaricata nel tuo computer. Fornisce maggiore sicurezza e richiede più spazio di archiviazione locale.
</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsNode.qml" line="214"/>
        <source>Remote node</source>
        <translation>Nodo remoto</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsNode.qml" line="230"/>
        <source>Uses a third-party server to connect to the Monero network. Less secure, but easier on your computer.</source>
        <translation>Utilizza un server di terze parti per connettersi alla rete Monero. Meno sicuro, ma meno intensivo per il tuo computer.</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsNode.qml" line="274"/>
        <source>To find a remote node, type &apos;Monero remote node&apos; into your favorite search engine. Please ensure the node is run by a trusted third-party.</source>
        <translation>Per trovare un nodo remoto, scrivi &apos;Monero remote node&apos; nel tuo motore di ricerca preferito. Assicurati che il nodo sia gestito da una terza parte affidabile.</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsNode.qml" line="282"/>
        <source>Address</source>
        <translation>Indirizzo</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsNode.qml" line="283"/>
        <source>Port</source>
        <translation>Porta</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsNode.qml" line="295"/>
        <source>Remote node updated. Trusted daemon has been reset. Mark again, if desired.</source>
        <translation>Nodo remoto aggiornato. Il daemon fidato è stato resettato. Marcalo di nuovo se desideri.</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsNode.qml" line="307"/>
        <source>Daemon username</source>
        <translation>Username Demone</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsNode.qml" line="309"/>
        <location filename="../pages/settings/SettingsNode.qml" line="412"/>
        <source>(optional)</source>
        <translation>(opzionale)</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsNode.qml" line="318"/>
        <source>Daemon password</source>
        <translation>Password per il demone</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsNode.qml" line="320"/>
        <source>Password</source>
        <translation>Password</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsNode.qml" line="335"/>
        <source>Mark as Trusted Daemon</source>
        <translation>Contrassegna come Daemon Fidato</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsNode.qml" line="342"/>
        <source>Connect</source>
        <translation>Connetti</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsNode.qml" line="365"/>
        <source>Start daemon</source>
        <translation>Avvia daemon</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsNode.qml" line="365"/>
        <source>Stop daemon</source>
        <translation>Arresta daemon</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsNode.qml" line="384"/>
        <source>Blockchain location</source>
        <translation>Posizione blockchain</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsNode.qml" line="384"/>
        <source> &lt;a href=&apos;#&apos;&gt; (change)&lt;/a&gt;</source>
        <translation> &lt;a href=&apos;#&apos;&gt; (cambia)&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsNode.qml" line="385"/>
        <source>(default)</source>
        <translation>(default)</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsNode.qml" line="411"/>
        <source>Daemon startup flags</source>
        <translation>Flag per il daemon</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsNode.qml" line="430"/>
        <source>Bootstrap Address</source>
        <translation>Indirizzo bootstrap</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsNode.qml" line="431"/>
        <source>Bootstrap Port</source>
        <translation>Porta bootstrap</translation>
    </message>
</context>
<context>
    <name>SettingsWallet</name>
    <message>
        <location filename="../pages/settings/SettingsWallet.qml" line="55"/>
        <source>Close this wallet</source>
        <translation>Chiudi questo portafoglio</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsWallet.qml" line="54"/>
        <source>Logs out of this wallet.</source>
        <translation>Esci da questo portafoglio.</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsWallet.qml" line="53"/>
        <source>Close wallet</source>
        <translation>Chiudi wallet</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsWallet.qml" line="63"/>
        <source>Create a view-only wallet</source>
        <translation>Crea un portafoglio Solo-visualizzazione</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsWallet.qml" line="62"/>
        <source>Creates a new wallet that can only view and initiate transactions, but requires a spendable wallet to sign transactions before sending.</source>
        <translation>Crea un nuovo wallet che può solo visualizzare e avviare transazioni, ma richiede un wallet spendibile per firmare le transazioni prima dell&apos;invio.</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsWallet.qml" line="61"/>
        <source>Create wallet</source>
        <translation>Crea portafoglio</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsWallet.qml" line="70"/>
        <source>Success</source>
        <translation>Successo</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsWallet.qml" line="71"/>
        <source>The view only wallet has been created with the same password as the current wallet. You can open it by closing this current wallet, clicking the &quot;Open wallet from file&quot; option, and selecting the view wallet in: 
%1
You can change the password in the wallet settings.</source>
        <translation>Il portafoglio solo-visualizzazione è stato creato con la stessa password del portafoglio corrente. Puoi aprirlo chiudendo questo portafoglio, facendo click sull&apos;opzione &quot;Apri portafoglio da file&quot; e selezionando il portafoglio solo-visualizzazione in: 
%1
Puoi cambiare la password nelle impostazioni del portafoglio.</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsWallet.qml" line="85"/>
        <source>Show seed &amp; keys</source>
        <translation>Mostra le chiavi &amp; seed</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsWallet.qml" line="84"/>
        <source>Store this information safely to recover your wallet in the future.</source>
        <translation>Conserva queste informazioni in modo sicuro per recuperare il tuo portafoglio in futuro.
</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsWallet.qml" line="83"/>
        <source>Show seed</source>
        <translation>Mostra seed</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsWallet.qml" line="95"/>
        <source>Rescan wallet balance</source>
        <translation>Scannerizza di nuovo il bilancio del portafoglio</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsWallet.qml" line="94"/>
        <source>Use this feature if you think the shown balance is not accurate.</source>
        <translation>Utilizza questa funzionalità se ritieni che il bilancio mostrato non sia accurato.</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsWallet.qml" line="93"/>
        <source>Rescan</source>
        <translation>Scannerizza di nuovo</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsWallet.qml" line="75"/>
        <location filename="../pages/settings/SettingsWallet.qml" line="101"/>
        <location filename="../pages/settings/SettingsWallet.qml" line="126"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsWallet.qml" line="102"/>
        <source>Error: </source>
        <translation>Errore: </translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsWallet.qml" line="107"/>
        <source>Information</source>
        <translation>Informazioni</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsWallet.qml" line="108"/>
        <source>Successfully rescanned spent outputs.</source>
        <translation>Scansione output spesi eseguita con successo.</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsWallet.qml" line="119"/>
        <source>Change wallet password</source>
        <translation>Cambia la password del portafoglio</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsWallet.qml" line="118"/>
        <source>Change the password of your wallet.</source>
        <translation>Cambia la password del tuo portafoglio.</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsWallet.qml" line="117"/>
        <source>Change password</source>
        <translation>Cambia password</translation>
    </message>
    <message>
        <location filename="../pages/settings/SettingsWallet.qml" line="127"/>
        <source>Wrong password</source>
        <translation>Password errata</translation>
    </message>
</context>
<context>
    <name>SharedRingDB</name>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="100"/>
        <source>Shared RingDB</source>
        <translation>Database degli anelli (RingDB) condiviso</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="104"/>
        <source>This page allows you to interact with the shared ring database. This database is meant for use by Monero wallets as well as wallets from Monero clones which reuse the Monero keys.</source>
        <translation>Questa pagina ti dà la possibilità di interagire con il database degli anelli condiviso (shared RingDB). Questo database è pensato per l&apos;utilizzo da parte dei portafogli Monero così come dai portafogli dei cloni Monero che riusano le chiavi Monero.</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="117"/>
        <location filename="../pages/SharedRingDB.qml" line="119"/>
        <source>Outputs marked as spent</source>
        <translation>Output con blackball applicato</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="117"/>
        <location filename="../pages/SharedRingDB.qml" line="254"/>
        <source>Help</source>
        <translation>Aiuto</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="120"/>
        <source>In order to obscure which inputs in a Monero transaction are being spent, a third party should not be able to tell which inputs in a ring are already known to be spent. Being able to do so would weaken the protection afforded by ring signatures. If all but one of the inputs are known to be already spent, then the input being actually spent becomes apparent, thereby nullifying the effect of ring signatures, one of the three main layers of privacy protection Monero uses.&lt;br&gt;To help transactions avoid those inputs, a list of known spent ones can be used to avoid using them in new transactions. Such a list is maintained by the Monero project and is available on the getmonero.org website, and you can import this list here.&lt;br&gt;Alternatively, you can scan the blockchain (and the blockchain of key-reusing Monero clones) yourself using the monero-blockchain-mark-spent-outputs tool to create a list of known spent outputs.&lt;br&gt;</source>
        <translation>Al fine di oscurare gli input che vengono spesi in una transazione Monero, non deve essere consentito ad un osservatore di individuare in un anello gli input che sono già stati spesi. Essere in grado di fare questo significa indebolire la protezione offerta dalle firme ad anello. Se si fosse a conoscenza del fatto che tutti gli input tranne uno sono già stati spesi, l&apos;input che viene veramente speso sarebbe palese, annullando di fatto l&apos;effetto delle firme ad anello, uno dei tre principali strati di protezione della privacy utilizzati da Monero.&lt;br&gt;Per fare in modo che le transazioni escludano tali input, si può ricorrere ad una lista di input di cui è già nota l&apos;avvenuta spesa ed il cui uso può essere evitato in una nuova transazione. Questa lista viene manutenuta dal Progetto Monero ed è disponibile sul sito getmonero.org; puoi importare la lista qui.&lt;br&gt;Alternativamente, puoi effettuare tu stesso/a una scansione della blockchain (e della blockchain dei cloni di Monero che riusano le chiavi) mediante lo strumento monero-blockchain-mark-spent-outputs per creare una lista di output già spesi.&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="141"/>
        <source>This sets which outputs are known to be spent, and thus not to be used as privacy placeholders in ring signatures. </source>
        <translation>Questo imposta gli output di cui è nota l&apos;avvenuta spesa e che non devono essere usati nelle firme ad anello. </translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="142"/>
        <source>You should only have to load a file when you want to refresh the list. Manual adding/removing is possible if needed.</source>
        <translation>Dovrebbe essere sufficiente caricare un file se vuoi aggiornare la lista. L&apos;aggiunta o la rimozione manuale sono comunque possibili.</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="154"/>
        <source>Please choose a file from which to load outputs to mark as spent</source>
        <translation>Seleziona un file da cui caricare output con blackball applicata</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="168"/>
        <source>Path to file</source>
        <translation>Percorso del file</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="170"/>
        <source>Filename with outputs to mark as spent</source>
        <translation>Nome del file con output su cui applicare blackball</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="181"/>
        <source>Browse</source>
        <translation>Esplora</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="191"/>
        <source>Load</source>
        <translation>Carica</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="208"/>
        <source>Or manually mark a single output as spent/unspent:</source>
        <translation>O applica/rimuovi blackball ad un output singolo:</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="210"/>
        <source>Paste output amount</source>
        <translation>Incolla l&apos;ammontare in uscita</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="222"/>
        <source>Paste output offset</source>
        <translation>Incolla l&apos;output di compensazione (offset)</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="234"/>
        <source>Mark as spent</source>
        <translation>Applica blackball</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="242"/>
        <source>Mark as unspent</source>
        <translation>Rimuovi blackball</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="254"/>
        <location filename="../pages/SharedRingDB.qml" line="256"/>
        <source>Rings</source>
        <translation>Anelli</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="257"/>
        <source>In order to avoid nullifying the protection afforded by Monero&apos;s ring signatures, an output should not be spent with different rings on different blockchains. While this is normally not a concern, it can become one when a key-reusing Monero clone allows you to spend existing outputs. In this case, you need to ensure this existing outputs uses the same ring on both chains.&lt;br&gt;This will be done automatically by Monero and any key-reusing software which is not trying to actively strip you of your privacy.&lt;br&gt;If you are using a key-reusing Monero clone too, and this clone does not include this protection, you can still ensure your transactions are protected by spending on the clone first, then manually adding the ring on this page, which allows you to then spend your Monero safely.&lt;br&gt;If you do not use a key-reusing Monero clone without these safety features, then you do not need to do anything as it is all automated.&lt;br&gt;</source>
        <translation>Al fine di evitare di annullare la protezione delle firme ad anello di Monero, un Output non deve essere speso con anelli diversi su blockchain diverse. Anche se questo normalmente non è un problema, può diventarne uno quando un clone di Monero che riutilizza le chiavi consente di spendere gli Output esistenti. In questo caso, devi assicurarti che gli output esistenti usino lo stesso anello su entrambe le blockchain.&lt;br&gt;Questo sarà fatto automaticamente da Monero e da qualsiasi software di riutilizzo delle chiavi che non stia cercando attivamente di privarti della tua privacy.&lt;br&gt;Se stai utilizzando un clone di Monero che riutilizza le chiavi, e questo clone non include questa protezione, puoi comunque garantire che le tue transazioni siano protette spendendo prima sul clone, quindi aggiungendo manualmente l&apos;anello in questa pagina, che ti consente di spendere i tuoi Monero in sicurezza.&lt;br&gt;Se non usi un clone Monero che riutilizza le chiavi senza queste funzioni di sicurezza, non devi fare nulla perché è tutto automatizzato.&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="279"/>
        <source>This records rings used by outputs spent on Monero on a key reusing chain, so that the same ring may be reused to avoid privacy issues.</source>
        <translation>Questo registra gli anelli utilizzati dagli output spesi su Monero su una blockchain che riusa le chiavi; ciò vuol dire che potrebbe essere riusato il medesimo anello per evitare problemi di privacy.</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="290"/>
        <source>Key image</source>
        <translation>Immagine della chiave</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="292"/>
        <source>Paste key image</source>
        <translation>Inserisci immagine della chiave</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="309"/>
        <source>Get ring</source>
        <translation>Ottieni anello</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="321"/>
        <source>Get Ring</source>
        <translation>Ottieni Anello</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="327"/>
        <source>No ring found</source>
        <translation>Nessun anello trovato</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="345"/>
        <source>Set ring</source>
        <translation>Imposta anello</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="357"/>
        <source>Set Ring</source>
        <translation>Imposta Anello</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="376"/>
        <source>I intend to spend on key-reusing fork(s)</source>
        <translation>Ho intenzione di spendere su uno o più fork che riusano le chiavi</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="388"/>
        <source>I might want to spend on key-reusing fork(s)</source>
        <translation>Potrei voler spendere su uno o più fork che riusano le chiavi</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="400"/>
        <source>Relative</source>
        <translation>Relativo</translation>
    </message>
    <message>
        <location filename="../pages/SharedRingDB.qml" line="418"/>
        <source>Set segregation height:</source>
        <translation>Seleziona l&apos;altezza di segregazione:</translation>
    </message>
</context>
<context>
    <name>Sign</name>
    <message>
        <location filename="../pages/Sign.qml" line="62"/>
        <source>Good signature</source>
        <translation>Firma valida</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="63"/>
        <source>This is a good signature</source>
        <translation>Questa è una firma valida</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="67"/>
        <source>Bad signature</source>
        <translation>Firma non valida</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="68"/>
        <source>This signature did not verify</source>
        <translation>Questa firma non ha potuto essere verificata</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="106"/>
        <source>This page lets you sign/verify a message (or file contents) with your address.</source>
        <translation>Questa pagina ti consente di firmare/verificare un messaggio (o il contenuto di un file) con il tuo indirizzo.</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="136"/>
        <location filename="../pages/Sign.qml" line="184"/>
        <location filename="../pages/Sign.qml" line="298"/>
        <source>Message</source>
        <translation>Messaggio</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="102"/>
        <source>Sign/verify</source>
        <translation>Firma/verifica</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="122"/>
        <source>Mode</source>
        <translation>Modalità</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="149"/>
        <location filename="../pages/Sign.qml" line="201"/>
        <location filename="../pages/Sign.qml" line="314"/>
        <source>File</source>
        <translation>File</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="171"/>
        <source>Sign file</source>
        <translation>Firma file</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="171"/>
        <source>Sign message</source>
        <translation>Firma messaggio</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="186"/>
        <source>Enter a message to sign</source>
        <translation>Inserisci un messaggio da firmare</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="203"/>
        <location filename="../pages/Sign.qml" line="316"/>
        <source>Enter path to file</source>
        <translation>Inserisci percorso al file</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="215"/>
        <location filename="../pages/Sign.qml" line="327"/>
        <source>Browse</source>
        <translation>Esplora</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="231"/>
        <source>Click [Sign Message] to generate signature</source>
        <translation>Clicca [Firma messaggio] per generare la firma</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="231"/>
        <source>Click [Sign File] to generate signature</source>
        <translation>Clicca [Firma File] per generare la firma</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="245"/>
        <location filename="../pages/Sign.qml" line="365"/>
        <source>Clear</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="258"/>
        <source>Sign Message</source>
        <translation>Firma Messaggio</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="272"/>
        <source>Sign File</source>
        <translation>Firma File</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="290"/>
        <source>Verify message</source>
        <translation>Verifica messaggio</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="290"/>
        <source>Verify file</source>
        <translation>Verifica file</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="300"/>
        <source>Enter the message to verify</source>
        <translation>Inserisci messaggio da verificare</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="339"/>
        <source>Address</source>
        <translation>Indirizzo</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="342"/>
        <source>Enter the Monero Address (example: 44AFFq5kSiGBoZ...)</source>
        <translation>Inserisci l&apos;indirizzo Monero (esempio: 44AFFq5kSiGBoZ...)</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="352"/>
        <source>Enter the signature to verify</source>
        <translation>Inserisci firma da verificare</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="380"/>
        <source>Verify File</source>
        <translation>Verifica File</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="392"/>
        <source>Verify Message</source>
        <translation>Verifica Messaggio</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="404"/>
        <source>Please choose a file to sign</source>
        <translation>Scegli un file da firmare</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="229"/>
        <location filename="../pages/Sign.qml" line="350"/>
        <source>Signature</source>
        <translation>Firma</translation>
    </message>
    <message>
        <location filename="../pages/Sign.qml" line="415"/>
        <source>Please choose a file to verify</source>
        <translation>Scegli un file da verificare</translation>
    </message>
</context>
<context>
    <name>StandardDialog</name>
    <message>
        <location filename="../components/StandardDialog.qml" line="148"/>
        <source>Double tap to copy</source>
        <translation>Tocca due volte per copiare</translation>
    </message>
    <message>
        <location filename="../components/StandardDialog.qml" line="155"/>
        <source>Content copied to clipboard</source>
        <translation>Contenuto copiato negli appunti</translation>
    </message>
    <message>
        <location filename="../components/StandardDialog.qml" line="170"/>
        <source>Cancel</source>
        <translation>Cancella</translation>
    </message>
    <message>
        <location filename="../components/StandardDialog.qml" line="179"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>StandardDropdown</name>
    <message>
        <location filename="../components/StandardDropdown.qml" line="155"/>
        <source>Automatic</source>
        <translation type="unfinished">Automatico</translation>
    </message>
    <message>
        <location filename="../components/StandardDropdown.qml" line="156"/>
        <source>Slow (x0.2 fee)</source>
        <translation type="unfinished">Lento (commissione 0,25x) {0.2 ?}</translation>
    </message>
    <message>
        <location filename="../components/StandardDropdown.qml" line="157"/>
        <source>Normal (x1 fee)</source>
        <translation type="unfinished">Normale (commissione 1x)</translation>
    </message>
    <message>
        <location filename="../components/StandardDropdown.qml" line="158"/>
        <source>Fast (x5 fee)</source>
        <translation>Veloce (commissione 5x)</translation>
    </message>
    <message>
        <location filename="../components/StandardDropdown.qml" line="159"/>
        <source>Fastest (x200 fee)</source>
        <translation type="unfinished">Velocissimo (commissione 41,5x) {200 ?}</translation>
    </message>
</context>
<context>
    <name>Transfer</name>
    <message>
        <location filename="../pages/Transfer.qml" line="222"/>
        <source>Transaction priority</source>
        <translation>Priorità transazione</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="91"/>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="517"/>
        <source>Sign tx file</source>
        <translation>Firma file tx</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="528"/>
        <source>Submit tx file</source>
        <translation>Invia file tx</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="641"/>
        <source>Monero sent successfully</source>
        <translation>Moneroj inviati con successo</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="705"/>
        <source>Wallet is not connected to daemon.</source>
        <translation>Portafoglio non connesso al daemon.</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="724"/>
        <source>Connected daemon is not compatible with GUI. 
Please upgrade or connect to another daemon</source>
        <translation>Il daemon connesso non è compatibile con l&apos;interfaccia grafica. Aggiorna o connetti ad un altro daemon</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="87"/>
        <source>OpenAlias error</source>
        <translation>Errore OpenAlias</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="193"/>
        <source>All</source>
        <translation>Tutto</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="240"/>
        <source>Fast (x5 fee)</source>
        <translation>Veloce (commissione 5x)</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="267"/>
        <location filename="../pages/Transfer.qml" line="308"/>
        <source>Resolve</source>
        <translation>Risolvi</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="81"/>
        <source>&lt;style type=&apos;text/css&apos;&gt;a {text-decoration: none; color: #FF6C3C; font-size: 14px;}&lt;/style&gt;&lt;font size=&apos;2&apos;&gt; (&lt;/font&gt;&lt;a href=&apos;#&apos;&gt;Start daemon&lt;/a&gt;&lt;font size=&apos;2&apos;&gt;)&lt;/font&gt;</source>
        <translation>&lt;style type=&apos;text/css&apos;&gt;a {text-decoration: none; color: #FF6C3C; font-size: 14px;}&lt;/style&gt;&lt;font size=&apos;2&apos;&gt; (&lt;/font&gt;&lt;a href=&apos;#&apos;&gt;Avvia daemon&lt;/a&gt;&lt;font size=&apos;2&apos;&gt;)&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="239"/>
        <source>Normal (x1 fee)</source>
        <translation>Normale (commissione 1x)</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="264"/>
        <source>&lt;style type=&apos;text/css&apos;&gt;a {text-decoration: none; color: #858585; font-size: 14px;}&lt;/style&gt;                Address &lt;font size=&apos;2&apos;&gt;  ( &lt;/font&gt; &lt;a href=&apos;#&apos;&gt;Address book&lt;/a&gt;&lt;font size=&apos;2&apos;&gt; )&lt;/font&gt;</source>
        <translation>&lt;style type=&apos;text/css&apos;&gt;a {text-decoration: none; color: #858585; font-size: 14px;}&lt;/style&gt;                Indirizzo &lt;font size=&apos;2&apos;&gt;  ( &lt;/font&gt; &lt;a href=&apos;#&apos;&gt;Rubrica&lt;/a&gt;&lt;font size=&apos;2&apos;&gt; )&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="325"/>
        <source>No valid address found at this OpenAlias address</source>
        <translation>Nessun indirizzo valido trovato in questo indirizzo OpenAlias</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="330"/>
        <source>Address found, but the DNSSEC signatures could not be verified, so this address may be spoofed</source>
        <translation>Indirizzo trovato ma le firme DNSSEC non hanno potuto essere verificate. L&apos;indirizzo potrebbe essere alterato</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="334"/>
        <source>No valid address found at this OpenAlias address, but the DNSSEC signatures could not be verified, so this may be spoofed</source>
        <translation>Nessun indirizzo valido trovato in questo indirizzo OpenAlias ma le firme DNSSEC non hanno potuto essere verificate. L&apos;indirizzo potrebbe essere alterato</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="338"/>
        <location filename="../pages/Transfer.qml" line="342"/>
        <source>Internal error</source>
        <translation>Errore interno</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="346"/>
        <source>No address found</source>
        <translation>Nessun indirizzo trovato</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="380"/>
        <source>Saved to local wallet history</source>
        <translation>Salvato nello storico del portafoglio locale</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="440"/>
        <source>Send</source>
        <translation>Invia</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="478"/>
        <source>Advanced options</source>
        <translation>Opzioni avanzate</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="488"/>
        <source>Sweep Unmixable</source>
        <translation>Esegui sweep dei non mixabili</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="499"/>
        <source>Create tx file</source>
        <translation>Crea file tx</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="540"/>
        <source>Export key images</source>
        <translation>Esporta immagini della chiave</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="552"/>
        <source>Import key images</source>
        <translation>Importa immagini della chiave</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="578"/>
        <location filename="../pages/Transfer.qml" line="634"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="640"/>
        <source>Information</source>
        <translation>Informazioni</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="63"/>
        <source>Amount is more than unlocked balance.</source>
        <translation>L&apos;ammontare è superiore al saldo sbloccato.</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="567"/>
        <location filename="../pages/Transfer.qml" line="628"/>
        <location filename="../pages/Transfer.qml" line="672"/>
        <source>Please choose a file</source>
        <translation>Seleziona un file</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="179"/>
        <source>&lt;style type=&apos;text/css&apos;&gt;a {text-decoration: none; color: #858585; font-size: 14px;}&lt;/style&gt;                                   Amount &lt;font size=&apos;2&apos;&gt;  ( &lt;/font&gt; &lt;a href=&apos;#&apos;&gt;Change account&lt;/a&gt;&lt;font size=&apos;2&apos;&gt; )&lt;/font&gt;</source>
        <translation>&lt;style type=&apos;text/css&apos;&gt;a {text-decoration: none; color: #858585; font-size: 14px;}&lt;/style&gt;                                   Importo &lt;font size=&apos;2&apos;&gt;  ( &lt;/font&gt; &lt;a href=&apos;#&apos;&gt;Cambia account&lt;/a&gt;&lt;font size=&apos;2&apos;&gt; )&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="57"/>
        <source>Wallet is view-only and sends are not possible. Unless key images are imported, the balance reflects only incoming but not outgoing transactions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="70"/>
        <source>Address is invalid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="75"/>
        <source>Enter an amount.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="161"/>
        <source>Spendable funds: %1 XMR. Please wait ~%2 minutes for your whole balance to become spendable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="237"/>
        <source>Automatic</source>
        <translation>Automatico</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="238"/>
        <source>Slow (x0.2 fee)</source>
        <translation type="unfinished">Lento (commissione 0,25x) {0.2 ?}</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="241"/>
        <source>Fastest (x200 fee)</source>
        <translation type="unfinished">Velocissimo (commissione 41,5x) {200 ?}</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="352"/>
        <source>Description field contents match long payment ID format.           Please don&apos;t paste long payment ID into description field, your funds might be lost.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="370"/>
        <source>Add description</source>
        <translation>Aggiungi descrizione</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="397"/>
        <source>Add payment ID</source>
        <translation>Aggiungi ID pagamento</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="409"/>
        <source>64 hexadecimal characters</source>
        <translation>64 caratteri esadecimali</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="422"/>
        <source>Long payment IDs are obsolete.           Long payment IDs were not encrypted on the blockchain and would harm your privacy.           If the party you&apos;re sending to still requires a long payment ID, please notify them.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="579"/>
        <source>Can&apos;t load unsigned transaction: </source>
        <translation>Impossibile caricare transazione non firmata: </translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="586"/>
        <source>
Number of transactions: </source>
        <translation>
Numero di transazioni: </translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="588"/>
        <source>
Transaction #%1</source>
        <translation>
Transazione #%1</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="589"/>
        <source>
Recipient: </source>
        <translation>
Destinatario: </translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="590"/>
        <source>
payment ID: </source>
        <translation>
ID pagamento: </translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="591"/>
        <source>
Amount: </source>
        <translation>
Ammontare: </translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="592"/>
        <source>
Fee: </source>
        <translation>
Commissione: </translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="593"/>
        <source>
Ringsize: </source>
        <translation>
Dimensione anello: </translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="607"/>
        <source>Confirmation</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="635"/>
        <source>Can&apos;t submit transaction: </source>
        <translation>Impossibile inviare transazione: </translation>
    </message>
    <message>
        <location filename="../pages/Transfer.qml" line="729"/>
        <source>Waiting on daemon synchronization to finish.</source>
        <translation>In attesa della fine della sincronizzazione del daemon.</translation>
    </message>
</context>
<context>
    <name>TxKey</name>
    <message>
        <location filename="../pages/TxKey.qml" line="92"/>
        <location filename="../pages/TxKey.qml" line="165"/>
        <source>Address</source>
        <translation>Indirizzo</translation>
    </message>
    <message>
        <location filename="../pages/TxKey.qml" line="95"/>
        <location filename="../pages/TxKey.qml" line="168"/>
        <source>Recipient&apos;s wallet address</source>
        <translation>Indirizzo portafoglio del destinatario</translation>
    </message>
    <message>
        <location filename="../pages/TxKey.qml" line="80"/>
        <location filename="../pages/TxKey.qml" line="153"/>
        <source>Transaction ID</source>
        <translation>ID transazione</translation>
    </message>
    <message>
        <location filename="../pages/TxKey.qml" line="63"/>
        <source>Prove Transaction</source>
        <translation>Prova transazione</translation>
    </message>
    <message>
        <location filename="../pages/TxKey.qml" line="68"/>
        <source>Generate a proof of your incoming/outgoing payment by supplying the transaction ID, the recipient address and an optional message. 
For the case of outgoing payments, you can get a &apos;Spend Proof&apos; that proves the authorship of a transaction. In this case, you don&apos;t need to specify the recipient address.</source>
        <translation>Genera una prova del tuo pagamento in ricezione/invio fornendo l&apos;ID della transazione, l&apos;indirizzo del ricevente ed un messaggio opzionale.
Per i pagamenti in uscita, puoi avere una &apos;Prova di Spesa&apos; che conferma l&apos;autore della transazione. In questo caso non serve specificare l&apos;indirizzo del ricevente.</translation>
    </message>
    <message>
        <location filename="../pages/TxKey.qml" line="83"/>
        <location filename="../pages/TxKey.qml" line="156"/>
        <source>Paste tx ID</source>
        <translation>Inserisci ID tx</translation>
    </message>
    <message>
        <location filename="../pages/TxKey.qml" line="105"/>
        <location filename="../pages/TxKey.qml" line="178"/>
        <source>Message</source>
        <translation>Messaggio</translation>
    </message>
    <message>
        <location filename="../pages/TxKey.qml" line="107"/>
        <location filename="../pages/TxKey.qml" line="180"/>
        <source>Optional message against which the signature is signed</source>
        <translation>Messaggio opzionale su cui firmare</translation>
    </message>
    <message>
        <location filename="../pages/TxKey.qml" line="115"/>
        <source>Generate</source>
        <translation>Genera</translation>
    </message>
    <message>
        <location filename="../pages/TxKey.qml" line="136"/>
        <source>Check Transaction</source>
        <translation>Controlla transazione</translation>
    </message>
    <message>
        <location filename="../pages/TxKey.qml" line="140"/>
        <source>Verify that funds were paid to an address by supplying the transaction ID, the recipient address, the message used for signing and the signature.
For the case with Spend Proof, you don&apos;t need to specify the recipient address.</source>
        <translation>Verifica che dei fondi siano stati inviati ad un indirizzo fornendo l&apos;ID della transazione, l&apos;indirizzo del ricevente, il messaggio usato per firmare e la firma.
In caso di prova di spesa, non serve specificare l&apos;indirizzo del ricevente.</translation>
    </message>
    <message>
        <location filename="../pages/TxKey.qml" line="190"/>
        <source>Signature</source>
        <translation>Firma</translation>
    </message>
    <message>
        <location filename="../pages/TxKey.qml" line="192"/>
        <source>Paste tx proof</source>
        <translation>Inserisci prova tx</translation>
    </message>
    <message>
        <location filename="../pages/TxKey.qml" line="200"/>
        <source>Check</source>
        <translation>Valida</translation>
    </message>
    <message>
        <location filename="../pages/TxKey.qml" line="219"/>
        <source>If a payment had several transactions then each must be checked and the results combined.</source>
        <translation>Per un pagamento con multiple transazioni, ogni transazione deve essere validata ed i risultati combinati.</translation>
    </message>
</context>
<context>
    <name>Utils</name>
    <message>
        <location filename="../js/Utils.js" line="42"/>
        <source>Wrong password</source>
        <translation type="unfinished">Password errata</translation>
    </message>
    <message>
        <location filename="../js/Utils.js" line="60"/>
        <source>second ago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../js/Utils.js" line="62"/>
        <source>seconds ago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../js/Utils.js" line="66"/>
        <source>minute ago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../js/Utils.js" line="68"/>
        <source>minutes ago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../js/Utils.js" line="72"/>
        <source>hour ago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../js/Utils.js" line="74"/>
        <source>hours ago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../js/Utils.js" line="78"/>
        <location filename="../js/Utils.js" line="82"/>
        <source>day ago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../js/Utils.js" line="84"/>
        <source>days ago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../js/Utils.js" line="93"/>
        <source>Testnet</source>
        <translation type="unfinished">Testnet</translation>
    </message>
    <message>
        <location filename="../js/Utils.js" line="93"/>
        <source>Stagenet</source>
        <translation type="unfinished">Stagenet</translation>
    </message>
    <message>
        <location filename="../js/Utils.js" line="93"/>
        <source>Mainnet</source>
        <translation type="unfinished">Mainnet</translation>
    </message>
</context>
<context>
    <name>WizardAskPassword</name>
    <message>
        <location filename="../wizard/WizardAskPassword.qml" line="42"/>
        <source>Strength: </source>
        <translation>Forza: </translation>
    </message>
    <message>
        <location filename="../wizard/WizardAskPassword.qml" line="53"/>
        <location filename="../wizard/WizardAskPassword.qml" line="72"/>
        <source>Low</source>
        <translation>Basso</translation>
    </message>
    <message>
        <location filename="../wizard/WizardAskPassword.qml" line="74"/>
        <source>Medium</source>
        <translation>Medio</translation>
    </message>
    <message>
        <location filename="../wizard/WizardAskPassword.qml" line="76"/>
        <source>High</source>
        <translation>Alto</translation>
    </message>
    <message>
        <location filename="../wizard/WizardAskPassword.qml" line="85"/>
        <source>Give your wallet a password</source>
        <translation>Imposta una password per il tuo portafoglio</translation>
    </message>
    <message>
        <location filename="../wizard/WizardAskPassword.qml" line="86"/>
        <source>This password cannot be recovered. If you forget it then the wallet will have to be restored from your %1.</source>
        <translation>Questa password non può essere recuperata. Se è andata perduta, il portafoglio dovrà essere ripristinato dal tuo %1.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardAskPassword.qml" line="86"/>
        <source>25 word mnemonic seed</source>
        <translation>Seed mnemonico di 25 parole</translation>
    </message>
    <message>
        <location filename="../wizard/WizardAskPassword.qml" line="86"/>
        <source>hardware wallet</source>
        <translation>portafoglio hardware</translation>
    </message>
    <message>
        <location filename="../wizard/WizardAskPassword.qml" line="90"/>
        <source>&lt;b&gt;Enter a strong password&lt;/b&gt; (Using letters, numbers, and/or symbols).</source>
        <translation>&lt;b&gt;Inserisci una password complessa&lt;/b&gt; (Utilizzando lettere, numeri e / o simboli).</translation>
    </message>
    <message>
        <location filename="../wizard/WizardAskPassword.qml" line="144"/>
        <source>Password</source>
        <translation>Password</translation>
    </message>
    <message>
        <location filename="../wizard/WizardAskPassword.qml" line="202"/>
        <source>Password (confirm)</source>
        <translation>Password (conferma)</translation>
    </message>
</context>
<context>
    <name>WizardController</name>
    <message>
        <location filename="../wizard/WizardController.qml" line="308"/>
        <source>Please choose a file</source>
        <translation>Seleziona un file</translation>
    </message>
    <message>
        <location filename="../wizard/WizardController.qml" line="431"/>
        <source>Please proceed to the device...</source>
        <translation>Per favore procedi col dispositivo...</translation>
    </message>
    <message>
        <location filename="../wizard/WizardController.qml" line="435"/>
        <source>Creating wallet from device...</source>
        <translation>Creando portafoglio da dispositivo...</translation>
    </message>
    <message>
        <location filename="../wizard/WizardController.qml" line="436"/>
        <source>

Please check your hardware wallet –
your input may be required.</source>
        <translation>

Controlla il tuo portafoglio hardware -
potrebbe essere richiesta una azione da parte tua.</translation>
    </message>
</context>
<context>
    <name>WizardCreateDevice1</name>
    <message>
        <location filename="../wizard/WizardCreateDevice1.qml" line="51"/>
        <source>Choose your hardware device</source>
        <translation>Scegli il tuo dispositivo hardware</translation>
    </message>
    <message>
        <location filename="../wizard/WizardCreateDevice1.qml" line="78"/>
        <source>Create a new wallet</source>
        <translation>Crea un nuovo portafoglio</translation>
    </message>
    <message>
        <location filename="../wizard/WizardCreateDevice1.qml" line="79"/>
        <source>Using a hardware device.</source>
        <translation>Utilizzando un dispositivo hardware.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardCreateDevice1.qml" line="93"/>
        <source>Create a new wallet from device.</source>
        <translation>Crea un nuovo portafoglio dal dispositivo.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardCreateDevice1.qml" line="106"/>
        <source>Restore a wallet from device. Use this if you used your hardware wallet before.</source>
        <translation>Ripristina un portafoglio dal dispositivo. Utilizza questa opzione se in precedenza hai già usato il tuo portafoglio hardware.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardCreateDevice1.qml" line="125"/>
        <source>Wallet creation date as `YYYY-MM-DD` or restore height</source>
        <translation>Data creazione del portafoglio `AAAA-MM-GG` o altezza di ripristino</translation>
    </message>
    <message>
        <location filename="../wizard/WizardCreateDevice1.qml" line="128"/>
        <source>Restore height</source>
        <translation>Altezza di ripristino</translation>
    </message>
    <message>
        <location filename="../wizard/WizardCreateDevice1.qml" line="146"/>
        <source>Advanced options</source>
        <translation>Opzioni avanzate</translation>
    </message>
    <message>
        <location filename="../wizard/WizardCreateDevice1.qml" line="153"/>
        <source>Subaddress lookahead (optional)</source>
        <translation>Sottoindirizzo lookahead (opzionale)</translation>
    </message>
    <message>
        <location filename="../wizard/WizardCreateDevice1.qml" line="163"/>
        <location filename="../wizard/WizardCreateDevice1.qml" line="226"/>
        <source>Error writing wallet from hardware device. Check application logs.</source>
        <translation>Errore durante la scrittura del portafoglio da dispositivo hardware. Controlla i registri dell&apos;applicazione.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardCreateDevice1.qml" line="180"/>
        <source>Back to menu</source>
        <translation>Torna al menu</translation>
    </message>
    <message>
        <location filename="../wizard/WizardCreateDevice1.qml" line="181"/>
        <source>Create wallet</source>
        <translation>Crea portafoglio</translation>
    </message>
</context>
<context>
    <name>WizardCreateWallet1</name>
    <message>
        <location filename="../wizard/WizardCreateWallet1.qml" line="63"/>
        <source>Create a new wallet</source>
        <translation>Crea un nuovo portafoglio</translation>
    </message>
    <message>
        <location filename="../wizard/WizardCreateWallet1.qml" line="64"/>
        <source>Creates a new wallet on this computer.</source>
        <translation>Crea un nuovo portafoglio su questo computer.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardCreateWallet1.qml" line="92"/>
        <source>Mnemonic seed</source>
        <translation>Seed mnemonico</translation>
    </message>
    <message>
        <location filename="../wizard/WizardCreateWallet1.qml" line="130"/>
        <source>This seed is &lt;b&gt;very&lt;/b&gt; important to write down and keep secret. It is all you need to backup and restore your wallet.</source>
        <translation>È &lt;b&gt;molto importante&lt;/b&gt; prendere nota del seed e mantenerlo segreto. E&apos; tutto ciò di cui si ha bisogno per effettuare il backup ed il ripristino del proprio portafoglio.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardCreateWallet1.qml" line="152"/>
        <source>Wallet restore height</source>
        <translation>Altezza di ripristino del portafoglio</translation>
    </message>
    <message>
        <location filename="../wizard/WizardCreateWallet1.qml" line="187"/>
        <source>Should you restore your wallet in the future, specifying this block number will recover your wallet quicker.</source>
        <translation>Se dovessi ripristinare il tuo portafoglio in futuro, specificando questo numero di blocco ripristinerai il tuo portafoglio più rapidamente.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardCreateWallet1.qml" line="195"/>
        <source>Back to menu</source>
        <translation>Torna al menu</translation>
    </message>
</context>
<context>
    <name>WizardCreateWallet3</name>
    <message>
        <location filename="../wizard/WizardCreateWallet3.qml" line="59"/>
        <source>Daemon settings</source>
        <translation>Impostazioni del daemon</translation>
    </message>
    <message>
        <location filename="../wizard/WizardCreateWallet3.qml" line="60"/>
        <source>To be able to communicate with the Monero network your wallet needs to be connected to a Monero node. For best privacy it&apos;s recommended to run your own node.</source>
        <translation>Per essere in grado di comunicare con la rete Monero, il tuo portafoglio deve essere connesso a un nodo Monero. Per superiore privacy è consigliato operare il proprio nodo.</translation>
    </message>
</context>
<context>
    <name>WizardCreateWallet4</name>
    <message>
        <location filename="../wizard/WizardCreateWallet4.qml" line="60"/>
        <source>You&apos;re all set up!</source>
        <translation>È tutto pronto!</translation>
    </message>
    <message>
        <location filename="../wizard/WizardCreateWallet4.qml" line="61"/>
        <source>New wallet details:</source>
        <translation>Dettagli nuovo portafoglio:</translation>
    </message>
    <message>
        <location filename="../wizard/WizardCreateWallet4.qml" line="68"/>
        <source>Open wallet</source>
        <translation>Apri portafoglio</translation>
    </message>
</context>
<context>
    <name>WizardDaemonSettings</name>
    <message>
        <location filename="../wizard/WizardDaemonSettings.qml" line="52"/>
        <source>Start a node automatically in background (recommended)</source>
        <translation>Avvia automaticamente un nodo in background (raccomandato)</translation>
    </message>
    <message>
        <location filename="../wizard/WizardDaemonSettings.qml" line="75"/>
        <source>Blockchain location (optional)</source>
        <translation>Posizione della Blockchain (opzionale)</translation>
    </message>
    <message>
        <location filename="../wizard/WizardDaemonSettings.qml" line="77"/>
        <source>Default</source>
        <translation>Default</translation>
    </message>
    <message>
        <location filename="../wizard/WizardDaemonSettings.qml" line="81"/>
        <source>Browse</source>
        <translation>Esplora</translation>
    </message>
    <message>
        <location filename="../wizard/WizardDaemonSettings.qml" line="95"/>
        <source>Bootstrap node</source>
        <translation>Nodo bootstrap</translation>
    </message>
    <message>
        <location filename="../wizard/WizardDaemonSettings.qml" line="115"/>
        <source>Additionally, you may specify a bootstrap node to use Monero immediately.</source>
        <translation>Inoltre, è possibile specificare un nodo d&apos;avvio (bootstrap) per utilizzare Monero immediatamente.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardDaemonSettings.qml" line="163"/>
        <source>Connect to a remote node</source>
        <translation>Connettiti a un nodo remoto</translation>
    </message>
</context>
<context>
    <name>WizardHome</name>
    <message>
        <location filename="../wizard/WizardHome.qml" line="61"/>
        <source>Welcome to Monero.</source>
        <translation>Benvenuto/a in Monero.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardHome.qml" line="66"/>
        <source>Create a new wallet</source>
        <translation>Crea un nuovo portafoglio</translation>
    </message>
    <message>
        <location filename="../wizard/WizardHome.qml" line="67"/>
        <source>Choose this option if this is your first time using Monero.</source>
        <translation>Seleziona questa opzione se questa è la prima volta che usi Monero.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardHome.qml" line="87"/>
        <source>Create a new wallet from hardware</source>
        <translation>Crea un nuovo portafoglio da hardware</translation>
    </message>
    <message>
        <location filename="../wizard/WizardHome.qml" line="88"/>
        <source>Connect your hardware wallet to create a new Monero wallet.</source>
        <translation>Connetti il tuo portafoglio hardware per creare un nuovo portafoglio Monero.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardHome.qml" line="107"/>
        <source>Open a wallet from file</source>
        <translation>Apri un portafoglio da file</translation>
    </message>
    <message>
        <location filename="../wizard/WizardHome.qml" line="108"/>
        <source>Import an existing .keys wallet file from your computer.</source>
        <translation>Importa un file portafoglio .keys esistente dal tuo computer.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardHome.qml" line="126"/>
        <source>Restore wallet from keys or mnemonic seed</source>
        <translation>Ripristina portafoglio da chiave o seed mnemonico</translation>
    </message>
    <message>
        <location filename="../wizard/WizardHome.qml" line="127"/>
        <source>Enter your private keys or 25-word mnemonic seed to restore your wallet.</source>
        <translation>Inserisci le tue chiavi private o seed mnemonico di 25 parole per ripristinare il tuo portafoglio.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardHome.qml" line="143"/>
        <source>Change wallet mode</source>
        <translation>Cambia modalità del portafoglio</translation>
    </message>
    <message>
        <location filename="../wizard/WizardHome.qml" line="153"/>
        <source>Change language</source>
        <translation>Cambia lingua</translation>
    </message>
    <message>
        <location filename="../wizard/WizardHome.qml" line="167"/>
        <source>Advanced options</source>
        <translation>Opzioni avanzate</translation>
    </message>
    <message>
        <location filename="../wizard/WizardHome.qml" line="188"/>
        <source>Change Network:</source>
        <translation>Cambio Rete:</translation>
    </message>
    <message>
        <location filename="../wizard/WizardHome.qml" line="217"/>
        <source>Number of KDF rounds:</source>
        <translation>Numero di round KDF:</translation>
    </message>
</context>
<context>
    <name>WizardLang</name>
    <message>
        <location filename="../wizard/WizardLang.qml" line="71"/>
        <source>Language settings</source>
        <translation>Impostazioni lingua</translation>
    </message>
    <message>
        <location filename="../wizard/WizardLang.qml" line="94"/>
        <source>Change the language of the Monero GUI.</source>
        <translation>Cambia la lingua della GUI Monero.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardLang.qml" line="183"/>
        <source>Language changed.</source>
        <translation>La lingua è stata modificata.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardLang.qml" line="205"/>
        <source>Close</source>
        <translation>Chiuso</translation>
    </message>
</context>
<context>
    <name>WizardLanguage</name>
    <message>
        <location filename="../wizard/WizardLanguage.qml" line="158"/>
        <source>Language</source>
        <translation>Lingua</translation>
    </message>
    <message>
        <location filename="../wizard/WizardLanguage.qml" line="168"/>
        <source>Continue</source>
        <translation>Continua</translation>
    </message>
</context>
<context>
    <name>WizardModeBootstrap</name>
    <message>
        <location filename="../wizard/WizardModeBootstrap.qml" line="61"/>
        <source>About the bootstrap mode</source>
        <translation>Informazioni sulla modalità bootstrap</translation>
    </message>
    <message>
        <location filename="../wizard/WizardModeBootstrap.qml" line="72"/>
        <source>This mode will use a remote node whilst also syncing the blockchain. This is different from the first menu option (Simple mode), since it will only use the remote node until the blockchain is fully synced locally. It is a reasonable tradeoff for most people who care about privacy but also want the convenience of an automatic fallback option.</source>
        <translation>Questa modalità utilizzerà un nodo remoto mentre sincronizzerà la blockchain. Questo è diverso dalla prima opzione di menu (modalità Semplice), poiché quella utilizzerà un nodo remoto solo fino a quando la blockchain sarà completamente sincronizzata localmente. È un compromesso ragionevole per la maggior parte delle persone che si preoccupano della privacy ma vogliono anche la comodità di un&apos;opzione di ripiego automatica.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardModeBootstrap.qml" line="84"/>
        <source>Temporary use of remote nodes is useful in order to use Monero immediately (hence the name bootstrap), however be aware that when using remote nodes (including with the bootstrap setting), nodes could track your IP address, track your &quot;restore height&quot; and associated block request data, and send you inaccurate information to learn more about transactions you make.</source>
        <translation>L&apos;utilizzo temporaneo di nodi remoti è utile per iniziare a usare immediatamente Monero (da qui il nome bootstrap), tuttavia tieni presente che quando si usano nodi remoti (incluso con l&apos;impostazione bootstrap), i nodi potrebbero tracciare il tuo indirizzo IP, tracciare la tua &quot;altezza di ripristino&quot; e i dati associati alla richiesta di blocchi, nonché  inviarti informazioni inesatte sulle transazioni effettuate.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardModeBootstrap.qml" line="97"/>
        <source>Remain aware of these limitations. &lt;b&gt;Users who prioritize privacy and decentralization must use a full node instead&lt;/b&gt;.</source>
        <translation>Considera sempre queste limitazioni. &lt;b&gt;Gli utenti per cui la privacy e la decentralizzazione sono una priorità devono operare invece il proprio nodo completo&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardModeBootstrap.qml" line="104"/>
        <source>I understand the privacy implications of using a third-party server.</source>
        <translation>Comprendo le implicazioni sulla privacy dell&apos;utilizzo di un server di parti terze.</translation>
    </message>
</context>
<context>
    <name>WizardModeRemoteNodeWarning</name>
    <message>
        <location filename="../wizard/WizardModeRemoteNodeWarning.qml" line="61"/>
        <source>About the simple mode</source>
        <translation>Riguardo la modalità semplice</translation>
    </message>
    <message>
        <location filename="../wizard/WizardModeRemoteNodeWarning.qml" line="72"/>
        <source>This mode is ideal for managing small amounts of Monero. You have access to basic features for making and managing transactions. It will automatically connect to the Monero network so you can start using Monero immediately.</source>
        <translation>Questa modalità è ideale per gestire piccole quantità di Monero. Avrai accesso alle funzionalità di base per creare e gestire transazioni. Potrai inoltre collegarti automaticamente alla rete Monero in modo da poter utilizzare immediatamente Monero.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardModeRemoteNodeWarning.qml" line="85"/>
        <source>Remote nodes are useful if you are not able/don&apos;t want to download the whole blockchain, but be advised that malicious remote nodes could compromise some privacy. They could track your IP address, track your &quot;restore height&quot; and associated block request data, and send you inaccurate information to learn more about transactions you make.</source>
        <translation>I nodi remoti sono utili se non si è in grado e/o non si desidera scaricare l&apos;intera blockchain, ma è importante sapere che gli stessi nodi remoti possono compromettere la vostra privacy. Essi possono monitorare il vostro indirizzo IP, tracciare la vostra &quot;altezza di ripristino&quot; ed i dati di richiesta blocco associati. Inoltre potrebbero inviarvi informazioni imprecise riguardo le transazioni effettuate per ricevere più informazioni sulle vostre transazioni.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardModeRemoteNodeWarning.qml" line="100"/>
        <source>Remain aware of these limitations. &lt;b&gt;Users who prioritize privacy and decentralization must use a full node instead&lt;/b&gt;.</source>
        <translation>Consapevoli di queste limitazioni. &lt;b&gt;Gli utenti che hanno come priorità privacy e decentralizzazione dovrebbero utilizzare un nodo completo&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardModeRemoteNodeWarning.qml" line="107"/>
        <source>I understand the privacy implications of using a third-party server.</source>
        <translation>Sono consapevole delle implicazioni sulla privacy nell&apos;utilizzo di un server di terze parti.</translation>
    </message>
</context>
<context>
    <name>WizardModeSelection</name>
    <message>
        <location filename="../wizard/WizardModeSelection.qml" line="61"/>
        <source>Mode selection.</source>
        <translation>Selezione modalità.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardModeSelection.qml" line="62"/>
        <source>Please select the statement that best matches you.</source>
        <translation>Seleziona l&apos;opzione più adatta alle tue esigenze.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardModeSelection.qml" line="68"/>
        <location filename="../wizard/WizardModeSelection.qml" line="99"/>
        <source>Simple mode</source>
        <translation>Modalità semplice</translation>
    </message>
    <message>
        <location filename="../wizard/WizardModeSelection.qml" line="71"/>
        <source>Easy access to sending, receiving and basic functionality.</source>
        <translation>Accesso facilitato alle funzionalità di base, di invio e di ricezione.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardModeSelection.qml" line="102"/>
        <source>Easy access to sending, receiving and basic functionality. The blockchain is downloaded to your computer.</source>
        <translation>Accesso facilitato alle funzionalità di base, di invio e di ricezione. La blockchain viene scaricata sul proprio computer.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardModeSelection.qml" line="128"/>
        <source>Advanced mode</source>
        <translation>Modalità avanzata</translation>
    </message>
    <message>
        <location filename="../wizard/WizardModeSelection.qml" line="129"/>
        <source>Includes extra features like mining and message verification. The blockchain is downloaded to your computer.</source>
        <translation>Include funzionalità extra come il mining e la verifica dei messaggi. La blockchain viene scaricata sul proprio computer.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardModeSelection.qml" line="141"/>
        <source>Back to menu</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WizardNav</name>
    <message>
        <location filename="../wizard/WizardNav.qml" line="44"/>
        <source>Previous</source>
        <translation>Precedente</translation>
    </message>
    <message>
        <location filename="../wizard/WizardNav.qml" line="45"/>
        <source>Next</source>
        <translation>Prossimo</translation>
    </message>
</context>
<context>
    <name>WizardOpenWallet1</name>
    <message>
        <location filename="../wizard/WizardOpenWallet1.qml" line="67"/>
        <source>Open a wallet from file</source>
        <translation>Apri un portafoglio da file</translation>
    </message>
    <message>
        <location filename="../wizard/WizardOpenWallet1.qml" line="68"/>
        <source>Import an existing .keys wallet file from your computer.</source>
        <translation>Importa un file portafoglio .keys esistente dal tuo computer.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardOpenWallet1.qml" line="80"/>
        <source>Recently opened</source>
        <translation>Aperto recentemente</translation>
    </message>
    <message>
        <location filename="../wizard/WizardOpenWallet1.qml" line="131"/>
        <source>Mainnet</source>
        <translation>Mainnet</translation>
    </message>
    <message>
        <location filename="../wizard/WizardOpenWallet1.qml" line="132"/>
        <source>Testnet</source>
        <translation>Testnet</translation>
    </message>
    <message>
        <location filename="../wizard/WizardOpenWallet1.qml" line="133"/>
        <source>Stagenet</source>
        <translation>Stagenet</translation>
    </message>
    <message>
        <location filename="../wizard/WizardOpenWallet1.qml" line="288"/>
        <source>Browse filesystem</source>
        <translation>Sfogliare il filesystem</translation>
    </message>
    <message>
        <location filename="../wizard/WizardOpenWallet1.qml" line="287"/>
        <source>Back to menu</source>
        <translation>Torna al menu</translation>
    </message>
</context>
<context>
    <name>WizardRestoreWallet1</name>
    <message>
        <location filename="../wizard/WizardRestoreWallet1.qml" line="108"/>
        <source>Restore wallet</source>
        <translation>Ripristina portafoglio</translation>
    </message>
    <message>
        <location filename="../wizard/WizardRestoreWallet1.qml" line="109"/>
        <source>Restore wallet from keys or mnemonic seed.</source>
        <translation>Ripristina il portafoglio da chiavi o seed mnemonico.</translation>
    </message>
    <message>
        <location filename="../wizard/WizardRestoreWallet1.qml" line="123"/>
        <source>Restore from seed</source>
        <translation>Ripristina da seed</translation>
    </message>
    <message>
        <location filename="../wizard/WizardRestoreWallet1.qml" line="136"/>
        <source>Restore from keys</source>
        <translation>Ripristina da chiave</translation>
    </message>
    <message>
        <location filename="../wizard/WizardRestoreWallet1.qml" line="149"/>
        <source>Restore from QR Code</source>
        <translation>Ripristina da QR Code</translation>
    </message>
    <message>
        <location filename="../wizard/WizardRestoreWallet1.qml" line="214"/>
        <source>Enter your 25 (or 24) word mnemonic seed</source>
        <translation>Inserisci il tuo seed mnemonico da 25 (o 24) parole</translation>
    </message>
    <message>
        <location filename="../wizard/WizardRestoreWallet1.qml" line="227"/>
        <source>Account address (public)</source>
        <translation>Indirizzo portafoglio (pubblico)</translation>
    </message>
    <message>
        <location filename="../wizard/WizardRestoreWallet1.qml" line="239"/>
        <source>View key (private)</source>
        <translation>Chiave di visualizzazione (privata)</translation>
    </message>
    <message>
        <location filename="../wizard/WizardRestoreWallet1.qml" line="251"/>
        <source>Spend key (private)</source>
        <translation>Chiave di spesa (privata)</translation>
    </message>
    <message>
        <location filename="../wizard/WizardRestoreWallet1.qml" line="262"/>
        <source>Wallet creation date as `YYYY-MM-DD` or restore height</source>
        <translation>Data creazione del portafoglio `AAAA-MM-GG` o altezza di ripristino</translation>
    </message>
    <message>
        <location filename="../wizard/WizardRestoreWallet1.qml" line="265"/>
        <source>Restore height</source>
        <translation>Altezza di ripristino</translation>
    </message>
    <message>
        <location filename="../wizard/WizardRestoreWallet1.qml" line="286"/>
        <source>Back to menu</source>
        <translation>Torna al menù</translation>
    </message>
</context>
<context>
    <name>WizardRestoreWallet3</name>
    <message>
        <location filename="../wizard/WizardRestoreWallet3.qml" line="67"/>
        <source>Daemon settings</source>
        <translation>Impostazioni daemon</translation>
    </message>
    <message>
        <location filename="../wizard/WizardRestoreWallet3.qml" line="68"/>
        <source>To be able to communicate with the Monero network your wallet needs to be connected to a Monero node. For best privacy it&apos;s recommended to run your own node.

If you don&apos;t have the option to run your own node, there&apos;s an option to connect to a remote node.</source>
        <translation>Per essere in grado di comunicare con la rete Monero, il tuo portafoglio deve essere connesso a un nodo Monero. Per una migliore privacy, si consiglia di operare un proprio nodo locale.

Se non si ha la possibilità di operare un proprio nodo locale, ci si può connettere ad un nodo remoto.</translation>
    </message>
</context>
<context>
    <name>WizardRestoreWallet4</name>
    <message>
        <location filename="../wizard/WizardRestoreWallet4.qml" line="60"/>
        <source>You&apos;re all set up!</source>
        <translation>É tutto pronto!</translation>
    </message>
    <message>
        <location filename="../wizard/WizardRestoreWallet4.qml" line="61"/>
        <source>New wallet details:</source>
        <translation>Dettagli nuovo portafoglio:</translation>
    </message>
</context>
<context>
    <name>WizardSummary</name>
    <message>
        <location filename="../wizard/WizardSummary.qml" line="44"/>
        <source>Wallet name</source>
        <translation>Nome portafoglio</translation>
    </message>
    <message>
        <location filename="../wizard/WizardSummary.qml" line="50"/>
        <source>Wallet path</source>
        <translation>Percorso del portafoglio</translation>
    </message>
    <message>
        <location filename="../wizard/WizardSummary.qml" line="56"/>
        <source>Language</source>
        <translation>Lingua</translation>
    </message>
    <message>
        <location filename="../wizard/WizardSummary.qml" line="62"/>
        <source>Restore height</source>
        <translation>Altezza di ripristino</translation>
    </message>
    <message>
        <location filename="../wizard/WizardSummary.qml" line="70"/>
        <source>Daemon address</source>
        <translation>Indirizzo daemon</translation>
    </message>
    <message>
        <location filename="../wizard/WizardSummary.qml" line="77"/>
        <source>Bootstrap address</source>
        <translation>Indirizzo di bootstrap</translation>
    </message>
    <message>
        <location filename="../wizard/WizardSummary.qml" line="83"/>
        <source>Network Type</source>
        <translation>Tipo di rete</translation>
    </message>
</context>
<context>
    <name>WizardWalletInput</name>
    <message>
        <location filename="../wizard/WizardWalletInput.qml" line="73"/>
        <source>Wallet name</source>
        <translation>Nome portafoglio</translation>
    </message>
    <message>
        <location filename="../wizard/WizardWalletInput.qml" line="87"/>
        <source>Wallet location</source>
        <translation>Posizione del portafoglio</translation>
    </message>
    <message>
        <location filename="../wizard/WizardWalletInput.qml" line="93"/>
        <source>Browse</source>
        <translation>Esplora</translation>
    </message>
    <message>
        <location filename="../wizard/WizardWalletInput.qml" line="108"/>
        <source>Please choose a directory</source>
        <translation>Seleziona una cartella</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="329"/>
        <location filename="../main.qml" line="785"/>
        <location filename="../main.qml" line="797"/>
        <location filename="../main.qml" line="852"/>
        <location filename="../main.qml" line="864"/>
        <location filename="../main.qml" line="906"/>
        <location filename="../main.qml" line="915"/>
        <location filename="../main.qml" line="963"/>
        <location filename="../main.qml" line="1071"/>
        <location filename="../main.qml" line="1515"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../main.qml" line="637"/>
        <source>Waiting for daemon to sync</source>
        <translation>In attesa della sincronizzazione del daemon</translation>
    </message>
    <message>
        <location filename="../main.qml" line="639"/>
        <source>Daemon is synchronized (%1)</source>
        <translation>Il daemon è sincronizzato (%1)</translation>
    </message>
    <message>
        <location filename="../main.qml" line="641"/>
        <source>Wallet is synchronized</source>
        <translation>Il portafoglio è sincronizzato</translation>
    </message>
    <message>
        <location filename="../main.qml" line="809"/>
        <location filename="../main.qml" line="929"/>
        <source>Please confirm transaction:
</source>
        <translation>Conferma transazione:
</translation>
    </message>
    <message>
        <location filename="../main.qml" line="813"/>
        <location filename="../main.qml" line="930"/>
        <source>

Amount: </source>
        <translation>
		
Ammontare: </translation>
    </message>
    <message>
        <location filename="../main.qml" line="853"/>
        <source>Amount is wrong: expected number from %1 to %2</source>
        <translation>L&apos;ammontare è sbagliato: è previsto un numero tra %1 e %2</translation>
    </message>
    <message>
        <location filename="../main.qml" line="789"/>
        <location filename="../main.qml" line="907"/>
        <source>Can&apos;t create transaction: </source>
        <translation>Impossibile creare la transazione: </translation>
    </message>
    <message>
        <location filename="../main.qml" line="330"/>
        <location filename="../main.qml" line="548"/>
        <source>Couldn&apos;t open wallet: </source>
        <translation>Impossibile aprire portafoglio: </translation>
    </message>
    <message>
        <location filename="../main.qml" line="302"/>
        <source>Closing wallet...</source>
        <translation>Chiusura portafoglio...</translation>
    </message>
    <message>
        <location filename="../main.qml" line="509"/>
        <source>Please proceed to the device...</source>
        <translation>Per favore procedi col dispositivo...</translation>
    </message>
    <message>
        <location filename="../main.qml" line="521"/>
        <source>Opening wallet ...</source>
        <translation>Aprendo portafoglio ...</translation>
    </message>
    <message>
        <location filename="../main.qml" line="536"/>
        <location filename="../main.qml" line="543"/>
        <source>Repairing incompatible wallet cache. Resyncing wallet.</source>
        <translation>Riparando la cache di portafoglio non compatibile. Risincronizzando il portafoglio.</translation>
    </message>
    <message>
        <location filename="../main.qml" line="683"/>
        <source>Waiting for daemon to start...</source>
        <translation>In attesa dell&apos;avvio del daemon...</translation>
    </message>
    <message>
        <location filename="../main.qml" line="689"/>
        <source>Waiting for daemon to stop...</source>
        <translation>In attesa dell&apos;arresto del daemon...</translation>
    </message>
    <message>
        <location filename="../main.qml" line="717"/>
        <source>Daemon failed to start</source>
        <translation>Impossibile avviare daemon</translation>
    </message>
    <message>
        <location filename="../main.qml" line="718"/>
        <source>Please check your wallet and daemon log for errors. You can also try to start %1 manually.</source>
        <translation>Controlla i log del portafoglio e del daemon. Puoi anche tentare di avviare %1 manualmente.</translation>
    </message>
    <message>
        <location filename="../main.qml" line="734"/>
        <source>Daemon is synchronized</source>
        <translation>Il daemon è sincronizzato</translation>
    </message>
    <message>
        <location filename="../main.qml" line="787"/>
        <source>Can&apos;t create transaction: Wrong daemon version: </source>
        <translation>Impossibile creare transazione: Versione daemon sbagliata: </translation>
    </message>
    <message>
        <location filename="../main.qml" line="798"/>
        <location filename="../main.qml" line="916"/>
        <source>No unmixable outputs to sweep</source>
        <translation>Nessun output non mixabile su cui eseguire lo sweep</translation>
    </message>
    <message>
        <location filename="../main.qml" line="811"/>
        <source>Address: </source>
        <translation>Indirizzo: </translation>
    </message>
    <message>
        <location filename="../main.qml" line="815"/>
        <source>
Ringsize: </source>
        <translation>
Dimensione anello: </translation>
    </message>
    <message>
        <location filename="../main.qml" line="816"/>
        <source>

Number of transactions: </source>
        <translation>
		
Numero di transazioni: </translation>
    </message>
    <message>
        <location filename="../main.qml" line="817"/>
        <source>
Description: </source>
        <translation>
Descrizione: </translation>
    </message>
    <message>
        <location filename="../main.qml" line="819"/>
        <source>
Spending address index: </source>
        <translation>
Indice indirizzo di spesa: </translation>
    </message>
    <message>
        <location filename="../main.qml" line="839"/>
        <source>Creating transaction...</source>
        <translation>Creazione transazione...</translation>
    </message>
    <message>
        <location filename="../main.qml" line="840"/>
        <source>

Please check your hardware wallet –
your input may be required.</source>
        <translation>

Controlla il tuo portafoglio hardware -
potrebbe essere richiesta una azione da parte tua.</translation>
    </message>
    <message>
        <location filename="../main.qml" line="928"/>
        <source>Confirmation</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <location filename="../main.qml" line="955"/>
        <source>Sending transaction ...</source>
        <translation>Inviando la transazione ...</translation>
    </message>
    <message>
        <location filename="../main.qml" line="1014"/>
        <source>Payment proof</source>
        <translation>Prova di pagamento</translation>
    </message>
    <message>
        <location filename="../main.qml" line="1017"/>
        <source>Couldn&apos;t generate a proof because of the following reason: 
</source>
        <translation>Impossibile generare una prova per il seguente motivo:
</translation>
    </message>
    <message>
        <location filename="../main.qml" line="1047"/>
        <location filename="../main.qml" line="1066"/>
        <source>Payment proof check</source>
        <translation>Controllo prova pagamento</translation>
    </message>
    <message>
        <location filename="../main.qml" line="1050"/>
        <location filename="../main.qml" line="1068"/>
        <source>Bad signature</source>
        <translation>Firma non valida</translation>
    </message>
    <message>
        <location filename="../main.qml" line="1057"/>
        <source>This address received %1 monero, with %2 confirmation(s).</source>
        <translation>Questo indirizzo ha ricevuto %1 Monero con %2 conferma/e.</translation>
    </message>
    <message>
        <location filename="../main.qml" line="1068"/>
        <source>Good signature</source>
        <translation>Firma valida</translation>
    </message>
    <message>
        <location filename="../main.qml" line="1421"/>
        <location filename="../main.qml" line="2062"/>
        <source>Wrong password</source>
        <translation>Password errata</translation>
    </message>
    <message>
        <location filename="../main.qml" line="1462"/>
        <source>Warning</source>
        <translation>Avviso</translation>
    </message>
    <message>
        <location filename="../main.qml" line="1465"/>
        <source>Error: Filesystem is read only</source>
        <translation>Errore: Il filesystem è di sola lettura</translation>
    </message>
    <message>
        <location filename="../main.qml" line="1467"/>
        <source>Warning: There&apos;s only %1 GB available on the device. Blockchain requires ~%2 GB of data.</source>
        <translation>Avviso: ci sono solo %1 GB disponibili nel dispositivo. La blockchain richiede ~%2 GB di spazio.</translation>
    </message>
    <message>
        <location filename="../main.qml" line="1469"/>
        <source>Note: There&apos;s %1 GB available on the device. Blockchain requires ~%2 GB of data.</source>
        <translation>Nota: ci sono %1 GB disponibili nel dispositivo. La blockchain richiede ~%2 GB di spazio.</translation>
    </message>
    <message>
        <location filename="../main.qml" line="1471"/>
        <source>Note: lmdb folder not found. A new folder will be created.</source>
        <translation>Nota: cartella lmdb non trovata. Verrà creata una nuova cartella.</translation>
    </message>
    <message>
        <location filename="../main.qml" line="1474"/>
        <source>Cancel</source>
        <translation>Cancella</translation>
    </message>
    <message>
        <location filename="../main.qml" line="1512"/>
        <source>Password changed successfully</source>
        <translation>Password cambiata con successo</translation>
    </message>
    <message>
        <location filename="../main.qml" line="1516"/>
        <source>Error: </source>
        <translation>Errore: </translation>
    </message>
    <message>
        <location filename="../main.qml" line="1605"/>
        <source>Primary account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="1932"/>
        <source>Local node is running</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="1933"/>
        <source>Do you want to stop local node or keep it running in the background?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="1935"/>
        <source>Force stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="1936"/>
        <source>Keep it running</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="1998"/>
        <source>New version of Monero v%1 is available.&lt;br&gt;&lt;br&gt;Download:&lt;br&gt;%2&lt;br&gt;&lt;br&gt;SHA256 Hash:&lt;br&gt;%3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="2000"/>
        <source>New version of Monero v%1 is available. Check out getmonero.org</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.qml" line="1957"/>
        <source>Tap again to close...</source>
        <translation>Tocca di nuovo per chiudere...</translation>
    </message>
    <message>
        <location filename="../main.qml" line="812"/>
        <source>
Payment ID: </source>
        <translation>
ID pagamento: </translation>
    </message>
    <message>
        <location filename="../main.qml" line="814"/>
        <location filename="../main.qml" line="931"/>
        <source>
Fee: </source>
        <translation>
Commissione: </translation>
    </message>
    <message>
        <location filename="../main.qml" line="865"/>
        <source>Insufficient funds. Unlocked balance: %1</source>
        <translation>Fondi insufficienti. Saldo sbloccato: %1</translation>
    </message>
    <message>
        <location filename="../main.qml" line="964"/>
        <source>Couldn&apos;t send the money: </source>
        <translation>Impossibile inviare fondi: </translation>
    </message>
    <message>
        <location filename="../main.qml" line="968"/>
        <location filename="../main.qml" line="1511"/>
        <source>Information</source>
        <translation>Informazioni</translation>
    </message>
    <message>
        <location filename="../main.qml" line="974"/>
        <source>Monero sent successfully: %1 transaction(s) </source>
        <translation>Moneroj inviati con successo: %1 transazione/i </translation>
    </message>
    <message>
        <location filename="../main.qml" line="1565"/>
        <source>Please wait...</source>
        <translation>Attendere...</translation>
    </message>
    <message>
        <location filename="../main.qml" line="974"/>
        <source>Transaction saved to file: %1</source>
        <translation>Transazione salvata nel file: %1</translation>
    </message>
    <message>
        <location filename="../main.qml" line="1054"/>
        <source>This address received %1 monero, but the transaction is not yet mined</source>
        <translation>Questo indirizzo ha ricevuto %1 monero, ma la transazione non è ancora stata validata dalla rete</translation>
    </message>
    <message>
        <location filename="../main.qml" line="1061"/>
        <source>This address received nothing</source>
        <translation>Questo indirizzo non ha ricevuto nulla</translation>
    </message>
</context>
</TS>
